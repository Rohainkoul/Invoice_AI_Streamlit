# ============================================================
# Invoice AI V2 — V6.1 BLIND-BATCH GENERALIZATION PATCH
# ============================================================
# Run AFTER V6 (and after the tiny V6 summary cleanup if used).
#
# No retraining.
# No MODEL reload.
# No PROCESSOR reload.
#
# Fixes exposed by the 8-document blind synthetic stress test:
#   A) Summary headings "Subtotal" / "Grand Total"
#      in addition to "BASIC TOTAL" / "BILL AMOUNT".
#   B) Generic positive/negative summary adjustments:
#      Freight, Processing Charges, Rebate, Discount,
#      Packing & Forwarding, Carriage, etc.
#   C) OCR/image-only PDFs now receive the SAME V6 geometry,
#      GST and financial overlay by reconstructing rows from
#      the OCR boxes returned by the existing ingestion pipeline.
# ============================================================

from pathlib import Path
import shutil
import re

assert "_v6_apply_overlay" in globals(), (
    "❌ V6 is not loaded. Run the V6 runtime fix first."
)
assert "_ingest_document" in globals(), (
    "❌ Existing document-ingestion/OCR pipeline is not loaded."
)
assert "PROD_WORK_ROOT" in globals(), (
    "❌ PROD_WORK_ROOT is missing."
)

# Save original V6 native reader once, even if this patch is rerun.
if "_V61_NATIVE_READER_ORIGINAL" not in globals():
    _V61_NATIVE_READER_ORIGINAL = _v6_native_pages


# ============================================================
# 1. OCR PAGE DATA -> V6-LIKE GEOMETRY
# ============================================================

def _v61_rows_from_words(words, page_number, width=1000.0, height=1000.0):
    """
    Convert word records with x0/y0/x1/y1 into the row representation
    expected by the V6 geometry helpers.
    """
    words = sorted(
        words,
        key=lambda item: (
            float(item["y0"]),
            float(item["x0"]),
        ),
    )

    rows = []

    # Normalized OCR boxes are 0..1000. A ~4 px tolerance is
    # conservative for words belonging to the same OCR text row.
    y_tolerance = 4.5 if width >= 900 else 1.7

    for record in words:
        target = None

        for row in reversed(rows[-6:]):
            if abs(
                float(record["y0"])
                -
                float(row["y0"])
            ) <= y_tolerance:
                target = row
                break

        if target is None:
            target = {
                "page": int(page_number),
                "y0": float(record["y0"]),
                "words": [],
                "width": float(width),
            }
            rows.append(target)

        target["words"].append(record)
        target["y0"] = (
            sum(
                float(item["y0"])
                for item
                in target["words"]
            )
            /
            len(target["words"])
        )

    for row in rows:
        row["words"].sort(
            key=lambda item:
                float(item["x0"])
        )
        row["text"] = " ".join(
            str(item["text"])
            for item
            in row["words"]
        ).strip()

    return rows


def _v61_ocr_geometry_pages(input_path):
    """
    Use the already-existing production OCR/ingestion pipeline.
    No second OCR library is introduced.
    """
    input_path = Path(input_path)

    work_dir = (
        Path(PROD_WORK_ROOT)
        /
        (
            input_path.stem
            + "_v61_geometry"
        )
    )

    if work_dir.exists():
        shutil.rmtree(work_dir)

    work_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    ingested = _ingest_document(
        input_path,
        work_dir,
    )

    output = []

    for page in ingested:
        page_number = int(
            page["page_number"]
        )

        words = []

        for index, (word, box) in enumerate(
            zip(
                page.get("words", []),
                page.get("boxes", []),
            )
        ):
            text = str(word).strip()

            if not text:
                continue

            x0, y0, x1, y1 = [
                float(value)
                for value
                in box
            ]

            words.append(
                {
                    "page":
                        page_number,
                    "text":
                        text,
                    "x0":
                        x0,
                    "y0":
                        y0,
                    "x1":
                        x1,
                    "y1":
                        y1,
                    "x":
                        (x0 + x1) / 2.0,
                    "y":
                        (y0 + y1) / 2.0,
                    "block":
                        0,
                    "line":
                        0,
                    "word":
                        index,
                    "width":
                        1000.0,
                    "height":
                        1000.0,
                }
            )

        rows = _v61_rows_from_words(
            words,
            page_number,
            width=1000.0,
            height=1000.0,
        )

        output.append(
            {
                "page":
                    page_number,
                "width":
                    1000.0,
                "height":
                    1000.0,
                "words":
                    words,
                "rows":
                    rows,
                "text":
                    " ".join(
                        str(x)
                        for x
                        in page.get(
                            "words",
                            [],
                        )
                    ),
                "geometry_source":
                    "OCR_V61",
            }
        )

    return output


# ============================================================
# 2. V6 PAGE READER WITH OCR GEOMETRY FALLBACK
# ============================================================

def _v6_native_pages(input_path):
    """
    Native PDF geometry remains first choice.
    If PDF text is absent/unusable, use OCR geometry instead.
    """
    native_pages = (
        _V61_NATIVE_READER_ORIGINAL(
            input_path
        )
    )

    native_word_count = sum(
        len(
            page.get(
                "words",
                [],
            )
        )
        for page
        in native_pages
    )

    # Require some actual text, not merely a page object.
    if native_word_count >= 8:
        return native_pages

    print(
        "  V6.1: native geometry unavailable "
        "→ OCR geometry overlay"
    )

    try:
        ocr_pages = (
            _v61_ocr_geometry_pages(
                input_path
            )
        )

        ocr_word_count = sum(
            len(
                page.get(
                    "words",
                    [],
                )
            )
            for page
            in ocr_pages
        )

        if ocr_word_count:
            return ocr_pages

    except Exception as exc:
        print(
            "  ⚠️ V6.1 OCR geometry overlay "
            f"could not run: {type(exc).__name__}: {exc}"
        )

    return native_pages


# ============================================================
# 3. GENERIC SUBTOTAL / FINAL TOTAL ANCHORS
# ============================================================

def _v61_find_summary_row(
    pages,
    phrases,
):
    candidates = []

    for page in pages:
        for row in page.get(
            "rows",
            [],
        ):
            lower = (
                str(
                    row.get(
                        "text",
                        "",
                    )
                )
                .strip()
                .lower()
            )

            for priority, phrase in enumerate(
                phrases
            ):
                if phrase in lower:
                    amount = (
                        _v6_rightmost_amount(
                            row
                        )
                    )

                    if amount is None:
                        continue

                    candidates.append(
                        {
                            "priority":
                                priority,
                            "page":
                                int(
                                    row[
                                        "page"
                                    ]
                                ),
                            "y":
                                float(
                                    row[
                                        "y0"
                                    ]
                                ),
                            "amount":
                                float(
                                    amount
                                ),
                            "row":
                                row,
                        }
                    )

                    break

    if not candidates:
        return None, None

    # Prefer the strongest phrase; if duplicated on repeated pages,
    # choose the latest page/row containing the final financial summary.
    best_priority = min(
        item["priority"]
        for item
        in candidates
    )

    candidates = [
        item
        for item
        in candidates
        if item[
            "priority"
        ]
        ==
        best_priority
    ]

    selected = max(
        candidates,
        key=lambda item: (
            item["page"],
            item["y"],
        ),
    )

    return (
        selected["amount"],
        selected["row"],
    )


def _v6_explicit_basic_total(pages):
    # Strongest first.
    return _v61_find_summary_row(
        pages,
        [
            "basic total",
            "taxable value",
            "taxable amount",
            "sub total",
            "subtotal",
        ],
    )


def _v6_explicit_bill_amount(pages):
    return _v61_find_summary_row(
        pages,
        [
            "bill amount",
            "grand total",
            "invoice total",
            "net amount payable",
            "amount payable",
        ],
    )


# ============================================================
# 4. ROBUST SUMMARY ADJUSTMENT RECOVERY
# ============================================================

def _v6_summary_adjustments(
    pages,
    basic_row,
    bill_row,
):
    """
    Recover signed financial adjustments between subtotal and final total.

    Examples:
      Freight Charges          +750
      Discount               -1,200
      Processing Charges     +1,850
      Volume Rebate            -425
      Packing & Forwarding      +980
      Carriage Inward         +1,350
      KNITTING JW CHAR       -13,167.40

    GST and round-off are intentionally handled separately.
    """
    if (
        basic_row is None
        or
        bill_row is None
    ):
        return []

    output = []

    for page in pages:
        page_number = int(
            page["page"]
        )

        start_allowed = (
            page_number
            >
            int(
                basic_row["page"]
            )
            or
            (
                page_number
                ==
                int(
                    basic_row["page"]
                )
                and
                float(
                    basic_row["y0"]
                )
                <
                float("inf")
            )
        )

        end_allowed = (
            page_number
            <
            int(
                bill_row["page"]
            )
            or
            page_number
            ==
            int(
                bill_row["page"]
            )
        )

        if not (
            start_allowed
            and end_allowed
        ):
            continue

        for row in page.get(
            "rows",
            [],
        ):
            y = float(
                row["y0"]
            )

            if (
                page_number
                ==
                int(
                    basic_row["page"]
                )
                and
                y
                <=
                float(
                    basic_row["y0"]
                )
            ):
                continue

            if (
                page_number
                ==
                int(
                    bill_row["page"]
                )
                and
                y
                >=
                float(
                    bill_row["y0"]
                )
            ):
                continue

            text = str(
                row.get(
                    "text",
                    "",
                )
            ).strip()

            lower = (
                text.lower()
            )

            if not text:
                continue

            # Exclude known non-adjustment summary rows.
            if any(
                phrase
                in lower
                for phrase
                in [
                    "basic total",
                    "subtotal",
                    "sub total",
                    "taxable value",
                    "taxable amount",
                    "bill amount",
                    "grand total",
                    "invoice total",
                    "amount payable",
                    "round off",
                    "rounding off",
                    "central gst",
                    "state gst",
                    "integrated gst",
                    "intigrate gst",
                    "cgst",
                    "sgst",
                    "igst",
                    "total value in words",
                    "amount in words",
                    "payment terms",
                    "currency",
                ]
            ):
                continue

            money = [
                item
                for item
                in _v6_money_tokens(
                    row
                )
                if not item[
                    "percent_related"
                ]
            ]

            if not money:
                continue

            amount_item = max(
                money,
                key=lambda item:
                    float(
                        item[
                            "word"
                        ][
                            "x0"
                        ]
                    ),
            )

            amount_x = float(
                amount_item[
                    "word"
                ][
                    "x0"
                ]
            )

            # Summary amounts are usually in the right side of the page.
            # OCR has slightly noisier boxes, so this is intentionally
            # less rigid than the original V6 75% threshold.
            if (
                amount_x
                <
                float(
                    page[
                        "width"
                    ]
                )
                *
                0.64
            ):
                continue

            label_words = [
                str(
                    word["text"]
                )
                for word
                in row["words"]
                if (
                    float(
                        word["x1"]
                    )
                    <
                    amount_x
                    and
                    float(
                        word["x0"]
                    )
                    >
                    float(
                        page[
                            "width"
                        ]
                    )
                    *
                    0.40
                    and
                    any(
                        char.isalpha()
                        for char
                        in str(
                            word[
                                "text"
                            ]
                        )
                    )
                )
            ]

            # If the label begins a little farther left, preserve it.
            if not label_words:
                label_words = [
                    str(
                        word["text"]
                    )
                    for word
                    in row["words"]
                    if (
                        float(
                            word["x1"]
                        )
                        <
                        amount_x
                        and
                        any(
                            char.isalpha()
                            for char
                            in str(
                                word[
                                    "text"
                                ]
                            )
                        )
                    )
                ]

            label = " ".join(
                label_words
            ).strip()

            if not label:
                continue

            # Reject narrative/note lines even if they contain a number.
            label_lower = (
                label.lower()
            )

            if any(
                phrase
                in label_lower
                for phrase
                in [
                    "inclusive inv",
                    "terms and condition",
                    "prepared by",
                    "authorized",
                    "remarks",
                    "reference no",
                    "po no",
                    "hsn",
                ]
            ):
                continue

            output.append(
                {
                    "label":
                        label,
                    "amount":
                        round(
                            float(
                                amount_item[
                                    "value"
                                ]
                            ),
                            2,
                        ),
                    "page":
                        page_number,
                    "row_text":
                        text,
                    "source":
                        "SUMMARY_ADJUSTMENT_V61",
                }
            )

    # Deduplicate exact repeated observations.
    deduped = []
    seen = set()

    for item in output:
        key = (
            re.sub(
                r"\s+",
                " ",
                item[
                    "label"
                ]
                .strip()
                .lower(),
            ),
            round(
                float(
                    item[
                        "amount"
                    ]
                ),
                2,
            ),
            int(
                item[
                    "page"
                ]
            ),
        )

        if key in seen:
            continue

        seen.add(key)
        deduped.append(
            item
        )

    return deduped


print("=" * 92)
print("🔥 V6.1 BLIND-BATCH GENERALIZATION PATCH READY 🔥")
print("✅ Subtotal / Grand Total summary anchors")
print("✅ Freight / discount / rebate / packing / carriage adjustments")
print("✅ Cross-page financial-summary window")
print("✅ OCR/image-only geometry overlay for V6 GST + finance logic")
print("No retraining. No MODEL reload. No PROCESSOR reload.")
print("Rerun ONLY the failed blind tests: 01, 04, 05, 06, 08.")
print("=" * 92)
