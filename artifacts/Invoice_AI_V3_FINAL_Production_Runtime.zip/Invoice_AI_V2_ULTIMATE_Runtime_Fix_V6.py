# ============================================================
# Invoice AI V2 — ULTIMATE RUNTIME FIX V6
# ============================================================
# PURPOSE
#   One conservative production overlay for the already-loaded model.
#   It does NOT retrain or reload MODEL / PROCESSOR.
#
# BUILT TO HANDLE THE REFERENCE LAYOUTS:
#   - Standard Dollar Industries invoices:
#       Purchase / Stitching / Yarn / Accessory / Processing /
#       Knitting / Fibre, single-page and multi-page.
#   - Vendor-posting invoice layout:
#       GL tax table + separate Material/UoM/Quantity table.
#
# WHAT V6 FIXES
#   1. Native-PDF geometry based line-item extraction.
#   2. Multiple table layouts (standard + material/quantity).
#   3. Multi-page: invoice lines from the primary table, totals from
#      the page that actually contains BASIC TOTAL / BILL AMOUNT.
#   4. GST rate vs GST amount separation.
#   5. Chooses CGST/SGST/IGST components using invoice arithmetic,
#      preventing 9.00% from becoming a 9.00 tax amount.
#   6. Generic extra-charge / deduction / round-off reconciliation.
#   7. Counterparty recovery from "Form ..." on standard invoices,
#      while rejecting internal/self-party blocks.
#   8. Complete top-header vendor address recovery.
#   9. Native GSTIN recovery.
#  10. Conservative NOT_PRESENT handling: never invent absent fields.
#  11. Clean V6 printer + canonical JSON output.
#
# REQUIREMENT
#   Run after the existing production cells / V5 in the SAME runtime.
# ============================================================

import copy
import json
import math
import re
from difflib import SequenceMatcher
from itertools import product
from pathlib import Path

import pymupdf as fitz

assert "process_invoice_v3" in globals(), (
    "❌ process_invoice_v3 is missing. Run the existing production/V5 cells first."
)
assert "TARGET_FIELDS" in globals(), "❌ TARGET_FIELDS is missing."
assert "PROD_OUTPUT_ROOT" in globals(), "❌ PROD_OUTPUT_ROOT is missing."

if "NOT_DETECTED" not in globals():
    NOT_DETECTED = "NOT_DETECTED"


# ============================================================
# 1. BASIC HELPERS
# ============================================================

def _v6_norm(value):
    return re.sub(
        r"[^a-z0-9]+",
        "",
        str(value).lower(),
    )


def _v6_missing(value):
    if value is None:
        return True

    if isinstance(value, str):
        return value.strip() in {
            "",
            NOT_DETECTED,
        }

    if isinstance(value, (list, tuple)):
        return len(value) == 0

    return False


def _v6_format_money(value):
    return f"{float(value):,.2f}"


def _v6_parse_money(value):
    """
    Parse ordinary or trailing-minus invoice money:
      1,134.10  -> 1134.10
      0.30-     -> -0.30
      -25.00    -> -25.00

    Percentage strings are intentionally rejected here.
    """
    text = str(value).strip()

    if not text or "%" in text:
        return None

    negative = False

    if text.endswith("-"):
        negative = True
        text = text[:-1].strip()

    if text.startswith("-"):
        negative = True
        text = text[1:].strip()

    text = (
        text
        .replace(",", "")
        .replace("₹", "")
        .replace("$", "")
        .replace("€", "")
        .replace("£", "")
        .strip()
    )

    if not re.fullmatch(
        r"\d+(?:\.\d+)?",
        text,
    ):
        return None

    number = float(text)

    if negative:
        number *= -1.0

    return number


def _v6_safe_field(result, field):
    return (
        result
        .setdefault("fields", {})
        .setdefault(
            field,
            {
                "value": NOT_DETECTED,
                "status": "NOT_DETECTED",
                "source": "NOT_DETECTED",
            },
        )
    )


def _v6_set_field(
    result,
    field,
    value,
    status,
    source,
):
    result["fields"][field] = {
        "value": value,
        "status": status,
        "source": source,
    }


# ============================================================
# 2. NATIVE PDF WORDS + VISUAL ROWS
# ============================================================

def _v6_native_pages(input_path):
    input_path = Path(input_path)

    if input_path.suffix.lower() != ".pdf":
        return []

    document = fitz.open(str(input_path))
    pages = []

    try:
        for page_index, page in enumerate(document):
            words = []

            for raw in page.get_text("words"):
                (
                    x0, y0, x1, y1,
                    text,
                    block_no,
                    line_no,
                    word_no,
                ) = raw[:8]

                words.append(
                    {
                        "page": page_index + 1,
                        "text": str(text),
                        "x0": float(x0),
                        "y0": float(y0),
                        "x1": float(x1),
                        "y1": float(y1),
                        "x": float((x0 + x1) / 2),
                        "y": float((y0 + y1) / 2),
                        "block": int(block_no),
                        "line": int(line_no),
                        "word": int(word_no),
                        "width": float(page.rect.width),
                        "height": float(page.rect.height),
                    }
                )

            words.sort(
                key=lambda item: (
                    item["y0"],
                    item["x0"],
                )
            )

            # PyMuPDF often puts cells from one visual table row
            # into separate blocks. Cluster by almost-identical y.
            rows = []

            for record in words:
                target = None

                for row in reversed(rows[-4:]):
                    if abs(
                        float(record["y0"])
                        -
                        float(row["y0"])
                    ) <= 1.7:
                        target = row
                        break

                if target is None:
                    target = {
                        "page": page_index + 1,
                        "y0": float(record["y0"]),
                        "words": [],
                        "width": float(page.rect.width),
                    }
                    rows.append(target)

                target["words"].append(record)

                target["y0"] = (
                    sum(
                        float(item["y0"])
                        for item
                        in target["words"]
                    )
                    /
                    len(target["words"])
                )

            for row in rows:
                row["words"].sort(
                    key=lambda item: item["x0"]
                )
                row["text"] = " ".join(
                    item["text"]
                    for item
                    in row["words"]
                ).strip()

            pages.append(
                {
                    "page": page_index + 1,
                    "width": float(page.rect.width),
                    "height": float(page.rect.height),
                    "words": words,
                    "rows": rows,
                    "text": page.get_text("text"),
                }
            )

    finally:
        document.close()

    return pages


def _v6_money_tokens(row):
    output = []
    words = row["words"]

    for index, word in enumerate(words):
        text = str(word["text"]).strip()

        percent_related = (
            "%" in text
            or (
                index + 1 < len(words)
                and
                str(
                    words[index + 1]["text"]
                ).strip()
                == "%"
            )
        )

        value = _v6_parse_money(text)

        if value is None:
            continue

        output.append(
            {
                "word": word,
                "value": float(value),
                "percent_related": bool(
                    percent_related
                ),
                "index": index,
            }
        )

    return output


def _v6_rightmost_amount(row):
    candidates = [
        item
        for item in _v6_money_tokens(row)
        if not item["percent_related"]
    ]

    if not candidates:
        return None

    return max(
        candidates,
        key=lambda item:
            item["word"]["x0"],
    )["value"]


def _v6_rows_containing(
    pages,
    phrase,
):
    phrase = str(phrase).lower()
    output = []

    for page in pages:
        for row in page["rows"]:
            if phrase in row["text"].lower():
                output.append(row)

    return output


# ============================================================
# 3. EXPLICIT SUBTOTAL / TOTAL / ROUND-OFF
# ============================================================

def _v6_explicit_basic_total(pages):
    rows = _v6_rows_containing(
        pages,
        "basic total",
    )

    if not rows:
        return None, None

    row = rows[-1]

    return (
        _v6_rightmost_amount(row),
        row,
    )


def _v6_explicit_bill_amount(pages):
    rows = _v6_rows_containing(
        pages,
        "bill amount",
    )

    if not rows:
        return None, None

    row = rows[-1]

    return (
        _v6_rightmost_amount(row),
        row,
    )


def _v6_explicit_round_off(pages):
    rows = _v6_rows_containing(
        pages,
        "round off",
    )

    if not rows:
        return None

    row = rows[-1]
    amount = _v6_rightmost_amount(row)

    if amount is None:
        return None

    return {
        "value": round(
            float(amount),
            2,
        ),
        "page": row["page"],
        "row_text": row["text"],
        "source": "NATIVE_ROUND_OFF_V6",
    }


# ============================================================
# 4. GENERIC SUMMARY ADJUSTMENTS
#
# Examples covered without hardcoding company/value:
#   CARRIAGE INWARD
#   PROCESS CHARGES
#   KNITTING JW CHAR
#   STITCHING CHARGES
#   INV RM FIBER
# ============================================================

def _v6_summary_adjustments(
    pages,
    basic_row,
    bill_row,
):
    if (
        basic_row is None
        or bill_row is None
        or basic_row["page"]
           != bill_row["page"]
    ):
        return []

    page = pages[
        basic_row["page"] - 1
    ]

    output = []

    for row in page["rows"]:
        if not (
            float(basic_row["y0"])
            <
            float(row["y0"])
            <
            float(bill_row["y0"])
        ):
            continue

        text_lower = row["text"].lower()

        if any(
            phrase in text_lower
            for phrase in [
                "basic total",
                "bill amount",
                "total value",
                "round off",
                "central gst",
                "state gst",
                "integrated gst",
                "intigrate gst",
                "cgst",
                "sgst",
                "igst",
            ]
        ):
            continue

        money = [
            item
            for item
            in _v6_money_tokens(row)
            if not item[
                "percent_related"
            ]
        ]

        if not money:
            continue

        amount_item = max(
            money,
            key=lambda item:
                item["word"]["x0"],
        )

        # Summary amounts in these invoices are right-aligned.
        # This excludes NOTE / TDS commentary on the left.
        if (
            float(
                amount_item["word"]["x0"]
            )
            <
            float(page["width"]) * 0.75
        ):
            continue

        label_words = [
            word["text"]
            for word
            in row["words"]
            if (
                float(page["width"]) * 0.55
                <
                float(word["x0"])
                <
                float(
                    amount_item[
                        "word"
                    ]["x0"]
                )
                and
                any(
                    char.isalpha()
                    for char
                    in str(word["text"])
                )
            )
        ]

        label = " ".join(
            label_words
        ).strip()

        if not label:
            continue

        output.append(
            {
                "label": label,
                "amount": round(
                    float(
                        amount_item["value"]
                    ),
                    2,
                ),
                "page": row["page"],
                "row_text": row["text"],
                "source":
                    "NATIVE_SUMMARY_ADJUSTMENT_V6",
            }
        )

    return output


# ============================================================
# 5. GST COMPONENT CANDIDATES
# ============================================================

def _v6_gst_type(text):
    lower = str(text).lower()

    if (
        "cgst" in lower
        or "central gst" in lower
    ):
        return "CGST"

    if (
        "sgst" in lower
        or "state gst" in lower
    ):
        return "SGST"

    if (
        "igst" in lower
        or "integrated gst" in lower
        or "intigrate gst" in lower
    ):
        return "IGST"

    if (
        "gst" in lower
        and "%" in lower
    ):
        return "GST"

    return None


def _v6_gst_candidates(pages):
    output = []

    for page in pages:
        for row in page["rows"]:
            tax_type = _v6_gst_type(
                row["text"]
            )

            if tax_type is None:
                continue

            # Ignore GSTIN labels.
            if "gstin" in row["text"].lower():
                continue

            rate_match = re.search(
                r"(\d+(?:\.\d+)?)\s*%",
                row["text"],
            )

            if rate_match is None:
                rate_match = re.search(
                    r"@(\d+(?:\.\d+)?)",
                    row["text"],
                )

            rate = (
                float(
                    rate_match.group(1)
                )
                if rate_match is not None
                else None
            )

            amount_candidates = [
                item
                for item
                in _v6_money_tokens(row)
                if not item[
                    "percent_related"
                ]
            ]

            if not amount_candidates:
                continue

            # In rows such as:
            # INPUT CGST 9.00 % 18,009.00
            # this always selects 18,009.00, not 9.00.
            amount_item = max(
                amount_candidates,
                key=lambda item:
                    item["word"]["x0"],
            )

            amount = float(
                amount_item["value"]
            )

            if amount <= 0:
                continue

            output.append(
                {
                    "type": tax_type,
                    "rate_percent": rate,
                    "amount": round(
                        amount,
                        2,
                    ),
                    "page": row["page"],
                    "y": float(row["y0"]),
                    "row_text": row["text"],
                    "source":
                        "NATIVE_GST_ROW_V6",
                }
            )

    # Deduplicate identical visual observations.
    deduped = []
    seen = set()

    for item in output:
        key = (
            item["type"],
            item["rate_percent"],
            item["amount"],
            item["page"],
            round(
                item["y"],
                1,
            ),
        )

        if key in seen:
            continue

        seen.add(key)
        deduped.append(item)

    return deduped


def _v6_select_gst_components(
    candidates,
    expected_tax,
):
    if expected_tax is None:
        return []

    expected_tax = float(
        expected_tax
    )

    if abs(expected_tax) <= 0.05:
        return []

    by_type = {}

    for candidate in candidates:
        by_type.setdefault(
            candidate["type"],
            [],
        ).append(candidate)

    combinations = []

    # IGST/general GST is normally standalone.
    for tax_type in [
        "IGST",
        "GST",
    ]:
        for item in by_type.get(
            tax_type,
            [],
        ):
            combinations.append(
                [item]
            )

    # CGST + SGST pair.
    if (
        by_type.get("CGST")
        and
        by_type.get("SGST")
    ):
        for cgst in by_type["CGST"]:
            for sgst in by_type["SGST"]:
                combinations.append(
                    [
                        cgst,
                        sgst,
                    ]
                )

    else:
        for tax_type in [
            "CGST",
            "SGST",
        ]:
            for item in by_type.get(
                tax_type,
                [],
            ):
                combinations.append(
                    [item]
                )

    if not combinations:
        return []

    def combo_score(combo):
        total = sum(
            float(
                item["amount"]
            )
            for item
            in combo
        )

        difference = abs(
            total
            -
            expected_tax
        )

        # Tiny preference for visually earlier/main-table
        # candidates when arithmetic ties.
        y_penalty = (
            sum(
                float(
                    item.get(
                        "y",
                        0.0,
                    )
                )
                for item
                in combo
            )
            * 1e-9
        )

        return (
            difference,
            y_penalty,
        )

    best = min(
        combinations,
        key=combo_score,
    )

    return best


# ============================================================
# 6. STANDARD INVOICE TABLE
#
# Handles:
#   PO NO. [HSN] MATERIAL DESCRIPTION [MAT.GRP/Stor.loc/Batch]
#   GR QTY | BILL QTY | RATE | AMT INR
# ============================================================

def _v6_standard_table_header(page):
    for row in page["rows"]:
        lower = row["text"].lower()

        if (
            "material" in lower
            and
            "description" in lower
            and
            "rate" in lower
            and
            (
                "amt" in lower
                or "amount" in lower
            )
        ):
            return row

    return None


def _v6_standard_header_positions(
    header,
):
    words = header["words"]

    rate_word = next(
        (
            word
            for word
            in words
            if _v6_norm(
                word["text"]
            )
            == "rate"
        ),
        None,
    )

    amount_index = next(
        (
            index
            for index, word
            in reversed(
                list(
                    enumerate(words)
                )
            )
            if _v6_norm(
                word["text"]
            )
            in {
                "amt",
                "amount",
            }
        ),
        None,
    )

    if (
        rate_word is None
        or amount_index is None
    ):
        return None

    amount_words = [
        words[amount_index]
    ]

    if (
        amount_index + 1
        <
        len(words)
        and
        _v6_norm(
            words[
                amount_index + 1
            ]["text"]
        )
        in {
            "inr",
            "rs",
        }
    ):
        amount_words.append(
            words[
                amount_index + 1
            ]
        )

    amount_x = sum(
        item["x"]
        for item
        in amount_words
    ) / len(amount_words)

    bill_indexes = [
        index
        for index, word
        in enumerate(words)
        if _v6_norm(
            word["text"]
        )
        == "bill"
    ]

    qty_indexes = [
        index
        for index, word
        in enumerate(words)
        if _v6_norm(
            word["text"]
        )
        == "qty"
    ]

    if not (
        bill_indexes
        and qty_indexes
    ):
        return None

    bill_index = bill_indexes[-1]

    bill_qty_index = min(
        qty_indexes,
        key=lambda index:
            abs(
                words[index]["x"]
                -
                words[
                    bill_index
                ]["x"]
            ),
    )

    bill_qty_x = (
        words[bill_index]["x"]
        +
        words[
            bill_qty_index
        ]["x"]
    ) / 2

    gr_indexes = [
        index
        for index, word
        in enumerate(words)
        if _v6_norm(
            word["text"]
        )
        == "gr"
    ]

    gr_qty_x = None

    if gr_indexes:
        gr_index = gr_indexes[-1]

        gr_qty_index = min(
            qty_indexes,
            key=lambda index:
                abs(
                    words[index]["x"]
                    -
                    words[
                        gr_index
                    ]["x"]
                ),
        )

        gr_qty_x = (
            words[gr_index]["x"]
            +
            words[
                gr_qty_index
            ]["x"]
        ) / 2

    material_index = next(
        (
            index
            for index, word
            in enumerate(words)
            if _v6_norm(
                word["text"]
            )
            == "material"
        ),
        None,
    )

    description_index = next(
        (
            index
            for index, word
            in enumerate(words)
            if _v6_norm(
                word["text"]
            )
            == "description"
        ),
        None,
    )

    if (
        material_index is None
        or description_index is None
    ):
        return None

    if material_index > 0:
        description_left = (
            words[
                material_index - 1
            ]["x1"]
            + 8.0
        )
    else:
        description_left = max(
            0.0,
            words[
                material_index
            ]["x0"]
            - 50.0,
        )

    if (
        description_index + 1
        <
        len(words)
    ):
        # The first column after DESCRIPTION is centered;
        # leave enough margin to avoid MAT.GRP/Stor.loc leakage.
        description_right = (
            words[
                description_index + 1
            ]["x0"]
            - 20.0
        )
    else:
        description_right = (
            bill_qty_x - 100.0
        )

    return {
        "rate_x":
            float(rate_word["x"]),
        "amount_x":
            float(amount_x),
        "bill_qty_x":
            float(bill_qty_x),
        "gr_qty_x":
            (
                float(gr_qty_x)
                if gr_qty_x is not None
                else None
            ),
        "description_left":
            float(description_left),
        "description_right":
            float(description_right),
    }


def _v6_standard_line_items(page):
    header = _v6_standard_table_header(
        page
    )

    if header is None:
        return []

    positions = (
        _v6_standard_header_positions(
            header
        )
    )

    if positions is None:
        return []

    bill_qty_x = positions[
        "bill_qty_x"
    ]
    rate_x = positions[
        "rate_x"
    ]
    amount_x = positions[
        "amount_x"
    ]

    if positions[
        "gr_qty_x"
    ] is not None:
        qty_left = (
            positions[
                "gr_qty_x"
            ]
            +
            bill_qty_x
        ) / 2
    else:
        qty_left = (
            bill_qty_x - 25.0
        )

    qty_right = (
        bill_qty_x
        +
        rate_x
    ) / 2

    rate_left = qty_right

    rate_right = (
        rate_x
        +
        amount_x
    ) / 2

    amount_left = rate_right

    output = []
    started = False

    for row in page["rows"]:
        if (
            float(row["y0"])
            <=
            float(header["y0"]) + 3
        ):
            continue

        lower = row["text"].strip().lower()

        if re.match(
            r"^total\b",
            lower,
        ):
            if started:
                break

            continue

        if (
            "consumption details"
            in lower
            or "basic total"
            in lower
        ):
            if started:
                break

        money = _v6_money_tokens(
            row
        )

        qty_candidates = [
            item
            for item
            in money
            if (
                not item[
                    "percent_related"
                ]
                and
                qty_left
                <=
                item["word"]["x"]
                <=
                qty_right
            )
        ]

        rate_candidates = [
            item
            for item
            in money
            if (
                not item[
                    "percent_related"
                ]
                and
                rate_left
                <=
                item["word"]["x"]
                <=
                rate_right
            )
        ]

        amount_candidates = [
            item
            for item
            in money
            if (
                not item[
                    "percent_related"
                ]
                and
                item["word"]["x"]
                >=
                amount_left
            )
        ]

        if not (
            qty_candidates
            and
            rate_candidates
            and
            amount_candidates
        ):
            continue

        quantity = float(
            qty_candidates[-1]["value"]
        )

        rate = float(
            rate_candidates[-1]["value"]
        )

        amount = float(
            amount_candidates[-1][
                "value"
            ]
        )

        if (
            quantity <= 0
            or rate < 0
            or amount < 0
        ):
            continue

        arithmetic_difference = abs(
            quantity
            *
            rate
            -
            amount
        )

        if arithmetic_difference > max(
            0.05,
            abs(amount) * 0.002,
        ):
            continue

        description_words = [
            word["text"]
            for word
            in row["words"]
            if (
                positions[
                    "description_left"
                ]
                <=
                word["x0"]
                <
                positions[
                    "description_right"
                ]
            )
        ]

        description = " ".join(
            description_words
        ).strip()

        left_codes = [
            word["text"]
            for word
            in row["words"]
            if (
                word["x1"]
                <
                positions[
                    "description_left"
                ]
                and
                re.search(
                    r"\d",
                    str(
                        word["text"]
                    ),
                )
            )
        ]

        output.append(
            {
                "material_code":
                    (
                        left_codes[0]
                        if left_codes
                        else NOT_DETECTED
                    ),
                "description":
                    (
                        description
                        if description
                        else NOT_DETECTED
                    ),
                "hsn_code":
                    NOT_DETECTED,
                "uom":
                    NOT_DETECTED,
                "quantity":
                    str(
                        qty_candidates[-1][
                            "word"
                        ]["text"]
                    ),
                "quantity_numeric":
                    float(quantity),
                "unit_price":
                    round(
                        float(rate),
                        6,
                    ),
                "unit_price_source":
                    "NATIVE_TABLE_COLUMN_V6",
                "line_amount":
                    round(
                        float(amount),
                        2,
                    ),
                "line_amount_source":
                    "NATIVE_TABLE_COLUMN_V6",
                "page":
                    page["page"],
            }
        )

        started = True

    return output


# ============================================================
# 7. MATERIAL / UOM / QUANTITY TABLE
#
# Vendor-posting invoices can have:
#   Material | Material Description | UoM | Quantity
# but no printed line rate/amount.
#
# If all recovered rows are the SAME material/description and the
# invoice has a unique base subtotal, a uniform rate is mathematically
# determined and is marked DERIVED (never presented as directly printed).
# ============================================================

def _v6_material_qty_header(page):
    for row in page["rows"]:
        lower = row["text"].lower()

        if (
            "material"
            in lower
            and
            "description"
            in lower
            and
            "uom"
            in lower
            and
            "quantity"
            in lower
            and
            "rate"
            not in lower
            and
            "amount"
            not in lower
        ):
            return row

    return None


def _v6_material_qty_items(
    page,
    subtotal,
):
    header = _v6_material_qty_header(
        page
    )

    if header is None:
        return []

    words = header["words"]

    material_words = [
        word
        for word
        in words
        if _v6_norm(
            word["text"]
        )
        == "material"
    ]

    description_word = next(
        (
            word
            for word
            in words
            if _v6_norm(
                word["text"]
            )
            == "description"
        ),
        None,
    )

    uom_word = next(
        (
            word
            for word
            in words
            if _v6_norm(
                word["text"]
            )
            == "uom"
        ),
        None,
    )

    quantity_word = next(
        (
            word
            for word
            in words
            if _v6_norm(
                word["text"]
            )
            == "quantity"
        ),
        None,
    )

    if (
        len(material_words) < 2
        or description_word is None
        or uom_word is None
        or quantity_word is None
    ):
        return []

    code_description_boundary = (
        material_words[0]["x1"]
        + 10.0
    )

    description_uom_boundary = (
        uom_word["x0"]
        - 20.0
    )

    uom_quantity_boundary = (
        quantity_word["x0"]
        - 20.0
    )

    raw_items = []

    for row in page["rows"]:
        if (
            float(row["y0"])
            <=
            float(header["y0"]) + 3
        ):
            continue

        lower = row["text"].lower()

        if (
            "narration"
            in lower
            or "reference no"
            in lower
        ):
            break

        quantity_candidates = [
            item
            for item
            in _v6_money_tokens(row)
            if (
                not item[
                    "percent_related"
                ]
                and
                item["word"]["x0"]
                >=
                uom_quantity_boundary
            )
        ]

        if not quantity_candidates:
            continue

        quantity = float(
            quantity_candidates[-1][
                "value"
            ]
        )

        if quantity <= 0:
            continue

        code_words = [
            word["text"]
            for word
            in row["words"]
            if (
                word["x1"]
                <=
                code_description_boundary
                and
                re.search(
                    r"\d",
                    str(
                        word["text"]
                    ),
                )
            )
        ]

        description_words = [
            word["text"]
            for word
            in row["words"]
            if (
                code_description_boundary
                <
                word["x0"]
                <
                description_uom_boundary
                and
                any(
                    char.isalpha()
                    for char
                    in str(
                        word["text"]
                    )
                )
            )
        ]

        uom_words = [
            word["text"]
            for word
            in row["words"]
            if (
                description_uom_boundary
                <=
                word["x0"]
                <
                uom_quantity_boundary
                and
                any(
                    char.isalpha()
                    for char
                    in str(
                        word["text"]
                    )
                )
            )
        ]

        if not description_words:
            continue

        raw_items.append(
            {
                "material_code":
                    (
                        code_words[0]
                        if code_words
                        else NOT_DETECTED
                    ),
                "description":
                    " ".join(
                        description_words
                    ).strip(),
                "hsn_code":
                    NOT_DETECTED,
                "uom":
                    (
                        " ".join(
                            uom_words
                        ).strip()
                        or NOT_DETECTED
                    ),
                "quantity":
                    str(
                        quantity_candidates[-1][
                            "word"
                        ]["text"]
                    ),
                "quantity_numeric":
                    float(quantity),
                "unit_price":
                    None,
                "unit_price_source":
                    NOT_DETECTED,
                "line_amount":
                    None,
                "line_amount_source":
                    NOT_DETECTED,
                "page":
                    page["page"],
            }
        )

    if not raw_items:
        return []

    # Conservative derived uniform rate:
    # only when every item is the same material + description.
    comparable_keys = {
        (
            _v6_norm(
                item["material_code"]
            ),
            _v6_norm(
                item["description"]
            ),
        )
        for item
        in raw_items
    }

    total_quantity = sum(
        float(
            item["quantity_numeric"]
        )
        for item
        in raw_items
    )

    if (
        subtotal is not None
        and
        subtotal > 0
        and
        total_quantity > 0
        and
        len(comparable_keys) == 1
    ):
        derived_rate = (
            float(subtotal)
            /
            float(total_quantity)
        )

        derived_amounts = [
            round(
                float(
                    item[
                        "quantity_numeric"
                    ]
                )
                *
                derived_rate,
                2,
            )
            for item
            in raw_items
        ]

        difference = abs(
            sum(
                derived_amounts
            )
            -
            float(subtotal)
        )

        if difference <= 0.05:
            for item, amount in zip(
                raw_items,
                derived_amounts,
            ):
                item["unit_price"] = round(
                    float(
                        derived_rate
                    ),
                    6,
                )
                item[
                    "unit_price_source"
                ] = (
                    "DERIVED_UNIFORM_RATE_V6"
                )
                item["line_amount"] = float(
                    amount
                )
                item[
                    "line_amount_source"
                ] = (
                    "DERIVED_UNIFORM_RATE_V6"
                )

    return raw_items


# ============================================================
# 8. FORM-ROW COUNTERPARTY
# ============================================================

def _v6_form_party(page):
    form_words = [
        word
        for word
        in page["words"]
        if _v6_norm(
            word["text"]
        )
        == "form"
    ]

    if not form_words:
        return None

    form_word = form_words[0]
    form_y = float(
        form_word["y0"]
    )

    bill_words = [
        word
        for word
        in page["words"]
        if (
            _v6_norm(
                word["text"]
            )
            == "bill"
            and
            abs(
                float(word["y0"])
                -
                form_y
            )
            <= 3.0
        )
    ]

    max_x = (
        min(
            word["x0"]
            for word
            in bill_words
        )
        - 10.0
        if bill_words
        else
        float(page["width"]) * 0.62
    )

    gst_words = [
        word
        for word
        in page["words"]
        if (
            form_y - 2.0
            <=
            float(word["y0"])
            <=
            form_y + 15.0
            and
            str(
                word["text"]
            ).upper().startswith(
                "GST"
            )
        )
    ]

    if gst_words:
        max_x = min(
            max_x,
            min(
                word["x0"]
                for word
                in gst_words
            ),
        )

    candidates = [
        word
        for word
        in page["words"]
        if (
            float(word["x0"])
            >=
            float(form_word["x1"]) + 8.0
            and
            float(word["x0"])
            <
            max_x
            and
            (
                abs(
                    float(word["y0"])
                    -
                    form_y
                )
                <= 2.0
                or
                8.0
                <=
                float(word["y0"])
                -
                form_y
                <=
                15.0
            )
        )
    ]

    candidates.sort(
        key=lambda word: (
            word["y0"],
            word["x0"],
        )
    )

    output = []

    for word in candidates:
        text = str(
            word["text"]
        ).strip()

        if not text:
            continue

        normalized = _v6_norm(
            text
        )

        if normalized in {
            "add",
            "gst",
            "gstin",
        }:
            continue

        # Form code is the first code-looking token.
        if (
            not output
            and
            re.fullmatch(
                r"[A-Z0-9-]{5,}",
                text,
            )
            and
            any(
                char.isdigit()
                for char
                in text
            )
        ):
            continue

        output.append(text)

    party = " ".join(
        output
    ).strip()

    return (
        party
        if party
        else None
    )


def _v6_party_similarity(
    left,
    right,
):
    left = _v6_norm(left)
    right = _v6_norm(right)

    if not (
        left
        and right
    ):
        return 0.0

    return SequenceMatcher(
        None,
        left,
        right,
    ).ratio()


# ============================================================
# 9. COMPLETE TOP-HEADER ADDRESS
# ============================================================

def _v6_vendor_address(
    first_page,
    vendor_name,
):
    lines = [
        line.strip()
        for line
        in first_page["text"].splitlines()
        if line.strip()
    ]

    if not lines:
        return None

    vendor_norm = _v6_norm(
        vendor_name
    )

    vendor_index = 0
    best_score = -1.0

    for index, line in enumerate(
        lines[:10]
    ):
        score = SequenceMatcher(
            None,
            _v6_norm(line),
            vendor_norm,
        ).ratio()

        if score > best_score:
            best_score = score
            vendor_index = index

    output = []

    for line in lines[
        vendor_index + 1:
        vendor_index + 8
    ]:
        lower = line.lower()

        if (
            "invoice" in lower
            or lower.startswith(
                "doc no"
            )
            or lower == "to"
        ):
            break

        if any(
            phrase in lower
            for phrase in [
                "cin no",
                "email:",
                "ph no",
                "mfg.plant",
                "mfg. plant",
            ]
        ):
            continue

        address_like = (
            any(
                char.isdigit()
                for char
                in line
            )
            or "," in line
            or any(
                word in lower
                for word in [
                    "road",
                    "street",
                    "nagar",
                    "floor",
                    "palayam",
                    "market",
                    "kolkata",
                    "agra",
                    "vedasandur",
                    "pudukottai",
                    "wb",
                ]
            )
        )

        if address_like:
            output.append(line)

    address = " ".join(
        output
    ).strip()

    return (
        address
        if address
        else None
    )


# ============================================================
# 10. GSTIN RECOVERY FROM NATIVE TEXT
# ============================================================

_GSTIN_V6_RE = re.compile(
    r"\b"
    r"\d{2}"
    r"[A-Z]{5}"
    r"\d{4}"
    r"[A-Z]"
    r"[A-Z0-9]"
    r"Z"
    r"[A-Z0-9]"
    r"\b",
    re.I,
)


def _v6_native_gstins(pages):
    output = []
    seen = set()

    for page in pages:
        text = page["text"].upper()

        for match in _GSTIN_V6_RE.finditer(
            text
        ):
            value = match.group(0)

            if value in seen:
                continue

            seen.add(value)

            output.append(
                {
                    "value": value,
                    "page": page["page"],
                    "source":
                        "NATIVE_GSTIN_REGEX_V6",
                }
            )

    return output


# ============================================================
# 11. APPLY V6 OVERLAY
# ============================================================

def _v6_apply_overlay(
    input_path,
    base_result,
):
    result = copy.deepcopy(
        base_result
    )

    input_path = Path(
        input_path
    )

    if input_path.suffix.lower() != ".pdf":
        # Keep existing OCR/image behaviour unchanged.
        return result

    pages = _v6_native_pages(
        input_path
    )

    if not pages:
        return result

    fields = result["fields"]

    # --------------------------------------------------------
    # A. Explicit base subtotal / final bill amount
    # --------------------------------------------------------
    explicit_subtotal, basic_row = (
        _v6_explicit_basic_total(
            pages
        )
    )

    explicit_total, bill_row = (
        _v6_explicit_bill_amount(
            pages
        )
    )

    current_subtotal = _v6_parse_money(
        fields["SUBTOTAL"]["value"]
    )

    current_total = _v6_parse_money(
        fields[
            "TOTAL_AMOUNT"
        ]["value"]
    )

    subtotal = (
        explicit_subtotal
        if explicit_subtotal is not None
        else current_subtotal
    )

    total = (
        explicit_total
        if explicit_total is not None
        else current_total
    )

    if explicit_subtotal is not None:
        _v6_set_field(
            result,
            "SUBTOTAL",
            _v6_format_money(
                explicit_subtotal
            ),
            "RULE_RECOVERED",
            "NATIVE_BASIC_TOTAL_V6",
        )

    if explicit_total is not None:
        _v6_set_field(
            result,
            "TOTAL_AMOUNT",
            _v6_format_money(
                explicit_total
            ),
            "RULE_RECOVERED",
            "NATIVE_BILL_AMOUNT_V6",
        )

    # --------------------------------------------------------
    # B. Counterparty from Form-row
    # --------------------------------------------------------
    vendor_value = fields[
        "VENDOR_NAME"
    ]["value"]

    form_party = _v6_form_party(
        pages[0]
    )

    if form_party:
        similarity = (
            _v6_party_similarity(
                form_party,
                vendor_value,
            )
        )

        if similarity < 0.74:
            # Standard invoice Form-row is the external counterparty.
            _v6_set_field(
                result,
                "CUSTOMER_NAME",
                form_party,
                "RULE_RECOVERED",
                "FORM_COUNTERPARTY_V6",
            )
        else:
            # Internal/self invoice: do not invent a separate customer.
            current_customer = result[
                "fields"
            ][
                "CUSTOMER_NAME"
            ][
                "value"
            ]

            if (
                _v6_missing(
                    current_customer
                )
                or
                _v6_party_similarity(
                    current_customer,
                    vendor_value,
                )
                >= 0.74
            ):
                _v6_set_field(
                    result,
                    "CUSTOMER_NAME",
                    NOT_DETECTED,
                    "NOT_PRESENT",
                    "SELF_FORM_PARTY_V6",
                )

    # --------------------------------------------------------
    # C. Complete vendor address
    # --------------------------------------------------------
    address = _v6_vendor_address(
        pages[0],
        vendor_value,
    )

    if address:
        current_address = fields[
            "ADDRESS"
        ]["value"]

        if (
            _v6_missing(
                current_address
            )
            or
            len(address)
            >
            len(
                str(
                    current_address
                )
            )
            + 3
            or
            _v6_norm(
                current_address
            )
            in
            _v6_norm(
                address
            )
        ):
            _v6_set_field(
                result,
                "ADDRESS",
                address,
                "RULE_RECOVERED",
                "NATIVE_HEADER_ADDRESS_V6",
            )

    # --------------------------------------------------------
    # D. Line items
    # --------------------------------------------------------
    standard_items = (
        _v6_standard_line_items(
            pages[0]
        )
    )

    if standard_items:
        line_items = standard_items
        line_mode = (
            "STANDARD_NATIVE_TABLE_V6"
        )

    else:
        line_items = (
            _v6_material_qty_items(
                pages[0],
                subtotal,
            )
        )
        line_mode = (
            "MATERIAL_QTY_TABLE_V6"
        )

    if line_items:
        result["line_items"] = []

        for index, item in enumerate(
            line_items,
            1,
        ):
            output_item = dict(item)
            output_item[
                "line_number"
            ] = index

            # Keep stable key order for JSON readability.
            ordered = {
                "line_number":
                    index,
                "material_code":
                    output_item.get(
                        "material_code",
                        NOT_DETECTED,
                    ),
                "description":
                    output_item.get(
                        "description",
                        NOT_DETECTED,
                    ),
                "hsn_code":
                    output_item.get(
                        "hsn_code",
                        NOT_DETECTED,
                    ),
                "uom":
                    output_item.get(
                        "uom",
                        NOT_DETECTED,
                    ),
                "quantity":
                    output_item.get(
                        "quantity",
                        NOT_DETECTED,
                    ),
                "quantity_numeric":
                    output_item.get(
                        "quantity_numeric"
                    ),
                "unit_price":
                    output_item.get(
                        "unit_price"
                    ),
                "unit_price_source":
                    output_item.get(
                        "unit_price_source",
                        NOT_DETECTED,
                    ),
                "line_amount":
                    output_item.get(
                        "line_amount"
                    ),
                "line_amount_source":
                    output_item.get(
                        "line_amount_source",
                        NOT_DETECTED,
                    ),
                "page":
                    output_item.get(
                        "page"
                    ),
            }

            result[
                "line_items"
            ].append(ordered)

        descriptions = [
            item["description"]
            for item
            in result[
                "line_items"
            ]
        ]

        quantities = [
            item["quantity"]
            for item
            in result[
                "line_items"
            ]
        ]

        unit_prices = [
            (
                _v6_format_money(
                    item[
                        "unit_price"
                    ]
                )
                if item[
                    "unit_price"
                ]
                is not None
                else NOT_DETECTED
            )
            for item
            in result[
                "line_items"
            ]
        ]

        amounts = [
            (
                _v6_format_money(
                    item[
                        "line_amount"
                    ]
                )
                if item[
                    "line_amount"
                ]
                is not None
                else NOT_DETECTED
            )
            for item
            in result[
                "line_items"
            ]
        ]

        _v6_set_field(
            result,
            "LINE_ITEM_DESC",
            descriptions,
            "RULE_RECOVERED",
            line_mode,
        )

        _v6_set_field(
            result,
            "LINE_ITEM_QTY",
            quantities,
            "RULE_RECOVERED",
            line_mode,
        )

        if all(
            value
            != NOT_DETECTED
            for value
            in unit_prices
        ):
            _v6_set_field(
                result,
                "LINE_ITEM_UNIT_PRICE",
                unit_prices,
                "RULE_RECOVERED",
                line_mode,
            )

        if all(
            value
            != NOT_DETECTED
            for value
            in amounts
        ):
            _v6_set_field(
                result,
                "LINE_ITEM_AMOUNT",
                amounts,
                "RULE_RECOVERED",
                line_mode,
            )

    # --------------------------------------------------------
    # E. Summary adjustments + round off
    # --------------------------------------------------------
    round_off = (
        _v6_explicit_round_off(
            pages
        )
    )

    adjustments = (
        _v6_summary_adjustments(
            pages,
            basic_row,
            bill_row,
        )
    )

    adjustment_total = sum(
        float(
            item["amount"]
        )
        for item
        in adjustments
    )

    round_off_value = (
        float(
            round_off["value"]
        )
        if round_off is not None
        else 0.0
    )

    # Explicit discount/rebate rows can feed the target DISCOUNT,
    # while their signed amount remains in the generic arithmetic.
    discount_rows = [
        item
        for item
        in adjustments
        if any(
            keyword
            in item[
                "label"
            ].lower()
            for keyword
            in [
                "discount",
                "rebate",
                "disc ",
            ]
        )
    ]

    if discount_rows:
        discount_total = sum(
            abs(
                float(
                    item["amount"]
                )
            )
            for item
            in discount_rows
        )

        _v6_set_field(
            result,
            "DISCOUNT",
            _v6_format_money(
                discount_total
            ),
            "RECONCILED",
            "NATIVE_DISCOUNT_ROWS_V6",
        )

    # --------------------------------------------------------
    # F. GST components chosen by invoice arithmetic
    # --------------------------------------------------------
    gst_candidates = (
        _v6_gst_candidates(
            pages
        )
    )

    expected_tax = None

    if (
        subtotal is not None
        and total is not None
    ):
        expected_tax = (
            float(total)
            -
            float(subtotal)
            -
            float(
                adjustment_total
            )
            -
            float(
                round_off_value
            )
        )

        if abs(expected_tax) <= 0.05:
            expected_tax = 0.0

    selected_gst = (
        _v6_select_gst_components(
            gst_candidates,
            expected_tax,
        )
    )

    tax_total = (
        round(
            sum(
                float(
                    item["amount"]
                )
                for item
                in selected_gst
            ),
            2,
        )
        if selected_gst
        else None
    )

    if selected_gst:
        _v6_set_field(
            result,
            "TAX",
            _v6_format_money(
                tax_total
            ),
            "RECONCILED",
            "ARITHMETIC_GST_SELECTION_V6",
        )

    elif (
        expected_tax is not None
        and
        abs(expected_tax) <= 0.05
    ):
        _v6_set_field(
            result,
            "TAX",
            NOT_DETECTED,
            "NOT_PRESENT",
            "NO_TAX_REQUIRED_BY_ARITHMETIC_V6",
        )

    # --------------------------------------------------------
    # G. Native GSTINs
    # --------------------------------------------------------
    native_gstins = (
        _v6_native_gstins(
            pages
        )
    )

    if native_gstins:
        result.setdefault(
            "identifiers",
            {},
        )[
            "gstin_candidates"
        ] = native_gstins

    # --------------------------------------------------------
    # H. Rebuild normalized financials
    # --------------------------------------------------------
    subtotal = _v6_parse_money(
        result["fields"][
            "SUBTOTAL"
        ]["value"]
    )

    total = _v6_parse_money(
        result["fields"][
            "TOTAL_AMOUNT"
        ]["value"]
    )

    tax = _v6_parse_money(
        result["fields"][
            "TAX"
        ]["value"]
    )

    discount = _v6_parse_money(
        result["fields"][
            "DISCOUNT"
        ]["value"]
    )

    normalized = result.setdefault(
        "normalized",
        {},
    )

    normalized["subtotal"] = subtotal
    normalized["tax"] = tax
    normalized["discount"] = discount
    normalized[
        "total_amount"
    ] = total

    # --------------------------------------------------------
    # I. Exact financial reconciliation
    # --------------------------------------------------------
    calculated_total = None
    financial_difference = None
    financial_pass = None

    if (
        subtotal is not None
        and total is not None
    ):
        calculated_total = (
            float(subtotal)
            +
            float(
                tax
                if tax is not None
                else 0.0
            )
            +
            float(
                adjustment_total
            )
            +
            float(
                round_off_value
            )
        )

        # Do NOT subtract DISCOUNT again if it was already
        # represented as a signed summary adjustment.
        calculated_total = round(
            calculated_total,
            2,
        )

        financial_difference = round(
            abs(
                calculated_total
                -
                float(total)
            ),
            2,
        )

        financial_pass = (
            financial_difference
            <= 0.05
        )

    # --------------------------------------------------------
    # J. Line reconciliation
    # --------------------------------------------------------
    structured_items = result.get(
        "line_items",
        [],
    )

    quantity_values = [
        item.get(
            "quantity_numeric"
        )
        for item
        in structured_items
        if item.get(
            "quantity_numeric"
        )
        is not None
    ]

    amount_values = [
        item.get(
            "line_amount"
        )
        for item
        in structured_items
        if item.get(
            "line_amount"
        )
        is not None
    ]

    line_amount_sum = (
        round(
            sum(
                float(value)
                for value
                in amount_values
            ),
            2,
        )
        if (
            structured_items
            and
            len(amount_values)
            ==
            len(
                structured_items
            )
        )
        else None
    )

    line_difference = (
        round(
            abs(
                float(
                    line_amount_sum
                )
                -
                float(subtotal)
            ),
            2,
        )
        if (
            line_amount_sum
            is not None
            and
            subtotal is not None
        )
        else None
    )

    line_pass = (
        line_difference <= 0.05
        if line_difference
        is not None
        else None
    )

    # --------------------------------------------------------
    # K. GST reconciliation
    # --------------------------------------------------------
    gst_component_sum = (
        tax_total
        if selected_gst
        else None
    )

    gst_difference = (
        round(
            abs(
                float(
                    gst_component_sum
                )
                -
                float(tax)
            ),
            2,
        )
        if (
            gst_component_sum
            is not None
            and
            tax is not None
        )
        else None
    )

    gst_pass = (
        gst_difference <= 0.05
        if gst_difference
        is not None
        else None
    )

    result[
        "tax_details"
    ] = {
        "total_tax":
            tax,
        "gst_components":
            [
                {
                    "type":
                        item["type"],
                    "rate_percent":
                        item[
                            "rate_percent"
                        ],
                    "amount":
                        item["amount"],
                    "page":
                        item["page"],
                    "source":
                        item["source"],
                }
                for item
                in selected_gst
            ],
    }

    result[
        "financial_details"
    ] = {
        "round_off":
            round_off,
        "adjustments":
            adjustments,
        "adjustment_total":
            round(
                adjustment_total,
                2,
            ),
        "expected_tax_from_formula":
            (
                round(
                    expected_tax,
                    2,
                )
                if expected_tax
                is not None
                else None
            ),
    }

    validation = result.setdefault(
        "validation",
        {},
    )

    validation[
        "financial_reconciliation"
    ] = {
        "subtotal":
            subtotal,
        "tax":
            tax,
        "adjustments_total":
            round(
                adjustment_total,
                2,
            ),
        "round_off":
            (
                round_off_value
                if round_off
                is not None
                else None
            ),
        "total_amount":
            total,
        "calculated_total":
            calculated_total,
        "difference":
            financial_difference,
        "passed":
            financial_pass,
    }

    validation[
        "gst_reconciliation"
    ] = {
        "component_sum":
            gst_component_sum,
        "matches_tax_total":
            gst_pass,
        "difference":
            gst_difference,
    }

    validation[
        "line_item_reconciliation"
    ] = {
        "row_count":
            len(
                structured_items
            ),
        "total_quantity":
            (
                round(
                    sum(
                        float(value)
                        for value
                        in quantity_values
                    ),
                    6,
                )
                if quantity_values
                else None
            ),
        "line_amount_sum":
            line_amount_sum,
        "matches_subtotal":
            line_pass,
        "difference":
            line_difference,
    }

    # --------------------------------------------------------
    # L. Required/evidence-aware status
    # --------------------------------------------------------
    required_core = [
        "VENDOR_NAME",
        "INVOICE_NUMBER",
        "INVOICE_DATE",
        "CURRENCY",
        "TOTAL_AMOUNT",
    ]

    # Customer is required when an external Form party exists,
    # or an already-detected explicit To/customer exists.
    customer_required = False

    if form_party:
        customer_required = (
            _v6_party_similarity(
                form_party,
                result["fields"][
                    "VENDOR_NAME"
                ]["value"],
            )
            < 0.74
        )

    current_customer = result[
        "fields"
    ][
        "CUSTOMER_NAME"
    ][
        "value"
    ]

    if (
        not _v6_missing(
            current_customer
        )
        and
        result["fields"][
            "CUSTOMER_NAME"
        ].get(
            "status"
        )
        != "NOT_PRESENT"
    ):
        customer_required = True

    if customer_required:
        required_core.append(
            "CUSTOMER_NAME"
        )

    missing_core = [
        field
        for field
        in required_core
        if _v6_missing(
            result[
                "fields"
            ][field]["value"]
        )
    ]

    standard_header_present = (
        _v6_standard_table_header(
            pages[0]
        )
        is not None
    )

    material_qty_header_present = (
        _v6_material_qty_header(
            pages[0]
        )
        is not None
    )

    line_expected = (
        standard_header_present
        or material_qty_header_present
    )

    unresolved_expected = []

    if line_expected:
        for field in [
            "LINE_ITEM_DESC",
            "LINE_ITEM_QTY",
            "LINE_ITEM_UNIT_PRICE",
            "LINE_ITEM_AMOUNT",
        ]:
            if _v6_missing(
                result[
                    "fields"
                ][field]["value"]
            ):
                unresolved_expected.append(
                    field
                )

    tax_expected = (
        expected_tax is not None
        and
        abs(expected_tax) > 0.05
    )

    if (
        tax_expected
        and
        _v6_missing(
            result[
                "fields"
            ]["TAX"]["value"]
        )
    ):
        unresolved_expected.append(
            "TAX"
        )

    not_present = set(
        validation.get(
            "not_present_fields",
            [],
        )
    )

    for field in [
        "DUE_DATE",
        "DISCOUNT",
        "PAYMENT_TERMS",
    ]:
        if _v6_missing(
            result[
                "fields"
            ][field]["value"]
        ):
            not_present.add(field)

    if not customer_required and _v6_missing(
        result[
            "fields"
        ][
            "CUSTOMER_NAME"
        ][
            "value"
        ]
    ):
        not_present.add(
            "CUSTOMER_NAME"
        )

    if (
        not tax_expected
        and
        _v6_missing(
            result[
                "fields"
            ]["TAX"]["value"]
        )
    ):
        not_present.add(
            "TAX"
        )

    validation[
        "required_core_fields"
    ] = required_core

    validation[
        "missing_core_fields"
    ] = missing_core

    validation[
        "core_fields_pass"
    ] = not missing_core

    validation[
        "not_present_fields"
    ] = sorted(
        not_present
    )

    quality_flags = []

    if missing_core:
        quality_flags.append(
            "CORE_FIELDS_MISSING"
        )

    if financial_pass is False:
        quality_flags.append(
            "FINANCIAL_RECONCILIATION_FAILED"
        )

    if (
        line_expected
        and
        line_pass is not True
    ):
        quality_flags.append(
            "LINE_ITEM_RECONCILIATION_FAILED"
        )

    if (
        tax_expected
        and
        gst_pass is not True
    ):
        quality_flags.append(
            "GST_RECONCILIATION_FAILED"
        )

    if unresolved_expected:
        quality_flags.append(
            "EXPECTED_FIELDS_UNRESOLVED"
        )

    validation[
        "quality_flags"
    ] = quality_flags

    overall_pass = (
        not missing_core
        and
        financial_pass is not False
        and
        (
            not line_expected
            or line_pass is True
        )
        and
        (
            not tax_expected
            or gst_pass is True
        )
        and
        not unresolved_expected
    )

    overall_status = (
        "PASS"
        if overall_pass
        else "REVIEW_REQUIRED"
    )

    validation[
        "overall_status"
    ] = overall_status

    result["document"][
        "status"
    ] = overall_status

    # Stable ID from invoice number.
    invoice_number = result[
        "fields"
    ][
        "INVOICE_NUMBER"
    ][
        "value"
    ]

    if not _v6_missing(
        invoice_number
    ):
        result["document"][
            "document_id"
        ] = re.sub(
            r"[^A-Za-z0-9._-]+",
            "_",
            str(
                invoice_number
            ),
        )

    resolved_fields = [
        field
        for field
        in TARGET_FIELDS
        if not _v6_missing(
            result[
                "fields"
            ][field]["value"]
        )
    ]

    result[
        "extraction_summary"
    ] = {
        "target_field_count":
            len(
                TARGET_FIELDS
            ),
        "resolved_field_count":
            len(
                resolved_fields
            ),
        "resolved_fields":
            resolved_fields,
        "not_present_fields":
            sorted(
                not_present
            ),
        "unresolved_expected_fields":
            unresolved_expected,
        "required_core_fields":
            required_core,
        "missing_core_fields":
            missing_core,
        "line_item_mode":
            (
                line_mode
                if line_items
                else None
            ),
    }

    validation[
        "warnings"
    ] = [
        (
            f"{field} has no explicit evidence "
            "in the document; kept as NOT_DETECTED."
        )
        for field
        in sorted(
            not_present
        )
        if _v6_missing(
            result[
                "fields"
            ][field]["value"]
        )
    ]

    validation[
        "warnings"
    ].extend(
        [
            (
                f"{field} was expected but "
                "could not be resolved."
            )
            for field
            in unresolved_expected
        ]
    )

    result[
        "v6_audit"
    ] = {
        "native_pdf_overlay":
            True,
        "gst_candidates_seen":
            gst_candidates,
        "gst_components_selected":
            selected_gst,
        "form_counterparty":
            form_party,
        "native_vendor_address":
            address,
        "standard_table_detected":
            standard_header_present,
        "material_qty_table_detected":
            material_qty_header_present,
        "reference_safe_mode":
            "CONSERVATIVE_ARITHMETIC_AND_LAYOUT",
    }

    return result


# ============================================================
# 12. FINAL ENTRY POINT + CLEAN PRINTER
# ============================================================

def process_invoice_final(
    input_path,
    verbose=True,
):
    # Existing neural + V5 pipeline, no old printer.
    base_result = process_invoice_v3(
        input_path,
        verbose=False,
    )

    result = _v6_apply_overlay(
        input_path,
        base_result,
    )

    document_id = result[
        "document"
    ][
        "document_id"
    ]

    output_path = (
        Path(
            PROD_OUTPUT_ROOT
        )
        /
        f"{document_id}"
        "_invoice_extraction.json"
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            result,
            file,
            indent=2,
            ensure_ascii=False,
        )

    if verbose:
        print(
            "\n"
            +
            "=" * 92
        )
        print(
            "🔥 ULTIMATE PRODUCTION V6 RESULT 🔥"
        )
        print(
            "=" * 92
        )

        for field in TARGET_FIELDS:
            data = result[
                "fields"
            ][field]

            print(
                f"{field:<24}: "
                f"{data.get('value', NOT_DETECTED)}"
            )

            print(
                f"{'':24}  source = "
                f"{data.get('source', 'UNKNOWN')}"
            )

        print("\nLINE ITEMS")

        if result.get(
            "line_items"
        ):
            for item in result[
                "line_items"
            ]:
                print(
                    f"\n  LINE "
                    f"{item['line_number']}"
                )
                print(
                    "    Material:",
                    item.get(
                        "material_code",
                        NOT_DETECTED,
                    ),
                )
                print(
                    "    Desc    :",
                    item.get(
                        "description",
                        NOT_DETECTED,
                    ),
                )
                print(
                    "    UoM     :",
                    item.get(
                        "uom",
                        NOT_DETECTED,
                    ),
                )
                print(
                    "    Qty     :",
                    item.get(
                        "quantity",
                        NOT_DETECTED,
                    ),
                )
                print(
                    "    Rate    :",
                    item.get(
                        "unit_price",
                        NOT_DETECTED,
                    ),
                    "[",
                    item.get(
                        "unit_price_source",
                        NOT_DETECTED,
                    ),
                    "]",
                )
                print(
                    "    Amount  :",
                    item.get(
                        "line_amount",
                        NOT_DETECTED,
                    ),
                    "[",
                    item.get(
                        "line_amount_source",
                        NOT_DETECTED,
                    ),
                    "]",
                )
        else:
            print(
                "  NOT_DETECTED"
            )

        validation = result[
            "validation"
        ]

        print("\nVALIDATION")
        print(
            "  Core      :",
            validation.get(
                "core_fields_pass"
            ),
        )
        print(
            "  Financial :",
            validation.get(
                "financial_reconciliation",
                {},
            ).get(
                "passed"
            ),
        )
        print(
            "  GST       :",
            validation.get(
                "gst_reconciliation",
                {},
            ).get(
                "matches_tax_total"
            ),
        )
        print(
            "  Line      :",
            validation.get(
                "line_item_reconciliation",
                {},
            ).get(
                "matches_subtotal"
            ),
        )
        print(
            "  Flags     :",
            validation.get(
                "quality_flags",
                [],
            ),
        )

        financial_details = result.get(
            "financial_details",
            {},
        )

        print("\nFINANCIAL DETAILS")
        print(
            "  Round off :",
            financial_details.get(
                "round_off"
            ),
        )
        print(
            "  Adjustments:",
            financial_details.get(
                "adjustments",
                [],
            ),
        )

        summary = result[
            "extraction_summary"
        ]

        print("\nSUMMARY")
        print(
            "  Resolved  :",
            f"{summary['resolved_field_count']}"
            f"/{summary['target_field_count']}",
        )
        print(
            "  Not Present:",
            summary.get(
                "not_present_fields",
                [],
            ),
        )
        print(
            "  Unresolved:",
            summary.get(
                "unresolved_expected_fields",
                [],
            ),
        )
        print(
            "  Missing Core:",
            summary.get(
                "missing_core_fields",
                [],
            ),
        )
        print(
            "  Line mode :",
            summary.get(
                "line_item_mode"
            ),
        )
        print(
            "  Overall   :",
            validation.get(
                "overall_status"
            ),
        )
        print(
            "\nOutput:",
            output_path,
        )

    return result


print("=" * 92)
print("🔥 INVOICE AI V2 — ULTIMATE RUNTIME FIX V6 READY 🔥")
print("✅ Native geometry line tables: standard + material/quantity")
print("✅ Multi-page summary handling")
print("✅ GST rate/amount separation + arithmetic component selection")
print("✅ Generic charges/deductions/round-off reconciliation")
print("✅ Form counterparty + complete header address recovery")
print("✅ Native GSTIN recovery")
print("✅ Conservative NOT_PRESENT logic")
print("No retraining. No MODEL reload. No PROCESSOR reload.")
print("Rerun ONLY the invoice-upload cell.")
print("=" * 92)
