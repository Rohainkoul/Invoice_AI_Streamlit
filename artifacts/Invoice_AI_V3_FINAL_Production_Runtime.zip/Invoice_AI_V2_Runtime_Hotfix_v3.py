# ============================================================
# CELL 10C — PHASE 1.1 INFERENCE ROBUSTNESS HOTFIX
# No retraining. Uses the already-loaded MODEL + PROCESSOR.
#
# Fixes observed on unseen GST-style invoices:
# - suppresses harmless >512 token-count warning
# - safer customer validation/recovery
# - GSTIN recovery (including split tokens)
# - GST/CGST/SGST/IGST label parsing when joined with rate text
# - multi-row arithmetic table recovery (not just one best row)
# - discount-aware financial reconciliation
# - refreshed warnings/summary after rule recovery
# ============================================================

import copy
import math
import re
from difflib import SequenceMatcher
from pathlib import Path

assert "MODEL" in globals(), "MODEL is not loaded."
assert "PROCESSOR" in globals(), "PROCESSOR is not loaded."
assert "process_invoice_v2" in globals(), "Run the production V2 patch cell first."
assert "quality_records_v2" in globals(), "Run the production V2 patch cell first."

print("=" * 88)
print("🔥 CELL 10C — PHASE 1.1 ROBUSTNESS HOTFIX 🔥")
print("=" * 88)

NOT_DETECTED = "NOT_DETECTED"

# 1) Token counting only: silence the >512 warning.
# Actual model inference still uses the notebook's <=512 overlapping chunks.
def _word_token_counts(words, boxes):
    tokenized = PROCESSOR.tokenizer(
        text=words,
        boxes=boxes,
        add_special_tokens=False,
        truncation=False,
        verbose=False,
    )
    word_ids = tokenized.word_ids()
    counts = [0 for _ in words]
    for word_id in word_ids:
        if word_id is not None:
            counts[int(word_id)] += 1
    if not all(count > 0 for count in counts):
        raise RuntimeError("Tokenizer alignment failure.")
    return counts


# 2) Customer safety/recovery.
_CUSTOMER_STOP_V3 = {
    "gst", "gstin", "address", "invoice", "date", "ref", "po",
    "pan", "cin", "phone", "mobile", "email", "state", "pincode",
    "pin", "material", "description", "qty", "quantity", "amount",
}

def customer_valid_v2(value):
    if value in {None, "", NOT_DETECTED}:
        return False
    text = str(value).strip()
    if len(text) < 2 or len(text) > 120:
        return False
    if text.count("(") != text.count(")"):
        return False
    tokens = [
        re.sub(r"[^a-z0-9]+", "", token.lower())
        for token in text.split()
    ]
    tokens = [t for t in tokens if t]
    if not tokens or len(tokens) > 12:
        return False
    if any(token in _CUSTOMER_STOP_V3 for token in tokens):
        return False
    return any(any(ch.isalpha() for ch in token) for token in tokens)


def recover_customer_v2(records):
    anchors = [
        ("bill", "to"),
        ("billed", "to"),
        ("customer", "name"),
        ("customer",),
        ("buyer", "name"),
        ("buyer",),
        ("consignee", "name"),
        ("consignee",),
        ("sold", "to"),
        ("ship", "to"),
    ]

    for phrase in anchors:
        for hit in phrase_hits_v2(records, phrase):
            following = records[hit["list_end"] + 1: hit["list_end"] + 15]
            collected = []

            for rec in following:
                raw = str(rec["word"]).strip()
                cleaned = raw.strip(" :;,|\t\r\n")
                norm = rec["norm"]
                if not cleaned:
                    continue
                if norm in _CUSTOMER_STOP_V3 and collected:
                    break
                if (
                    not collected
                    and any(ch.isalpha() for ch in cleaned)
                    and any(ch.isdigit() for ch in cleaned)
                    and len(cleaned) <= 18
                ):
                    continue
                if collected and any(ch.isdigit() for ch in cleaned):
                    break
                collected.append(cleaned.rstrip(","))
                if len(collected) >= 7:
                    break

            for end in range(len(collected), 0, -1):
                candidate = " ".join(collected[:end]).strip()
                if customer_valid_v2(candidate):
                    return {
                        "value": candidate,
                        "source": "PARTY_ANCHOR_VALIDATED_V3",
                        "anchor": hit["anchor"],
                    }
    return None



# 3B) Safer final-total recovery.
# Prefer explicit payable/grand-total anchors and reject "Total Qty",
# tax totals, and subtotal/basic-total contexts.
_STRONG_TOTAL_ANCHORS_V3 = [
    ("amount", "payable"),
    ("grand", "total"),
    ("net", "amount"),
    ("net", "total"),
    ("invoice", "amount"),
    ("total", "amount"),
    ("bill", "amount"),
]

def _total_anchor_candidates_v3(records, include_generic=True):
    candidates = []

    phrases = list(_STRONG_TOTAL_ANCHORS_V3)
    if include_generic:
        phrases.append(("total",))

    for priority, phrase in enumerate(phrases):
        for hit in phrase_hits_v2(records, phrase):
            pos = hit["list_end"]
            context = records[max(0, hit["list_start"] - 3): min(len(records), pos + 5)]
            context_norms = {r["norm"] for r in context}

            if phrase == ("total",):
                # Reject summary labels that are not invoice totals.
                if context_norms & {
                    "qty", "quantity", "tax", "cgst", "sgst", "igst",
                    "subtotal", "basic", "taxable",
                }:
                    continue

            following = [
                r for r in records[pos + 1: pos + 8]
                if r["page"] == records[pos]["page"]
            ]

            money = []
            for rec in following:
                value = money_v2(rec["word"])
                if value is None or value < 0:
                    continue
                money.append((rec, float(value)))

            if not money:
                continue

            # Prefer a monetary value to the right of the anchor when geometry exists.
            anchor_x = records[pos].get("x")
            if anchor_x is not None:
                right = [
                    (r, v) for r, v in money
                    if r.get("x") is not None and float(r["x"]) >= float(anchor_x)
                ]
                if right:
                    money = right

            # For an explicit total line, the right-most amount is usually the final amount.
            if all(r.get("x") is not None for r, _ in money):
                rec, value = max(money, key=lambda pair: float(pair[0]["x"]))
            else:
                rec, value = money[0]

            candidates.append({
                "value": value,
                "text": rec["word"],
                "anchor": " ".join(phrase),
                "page": rec["page"],
                "index": rec["index"],
                "priority": priority,
                "list_position": pos,
            })

    # Stronger anchor first; if equally strong, later occurrence wins.
    candidates.sort(
        key=lambda c: (c["priority"], -c["list_position"])
    )
    return candidates


def recover_final_total_v2(records):
    candidates = _total_anchor_candidates_v3(records, include_generic=True)
    return candidates[0] if candidates else None


# 3) GSTIN recovery, including values split across tokens.
_GSTIN_RE_V3 = re.compile(
    r"^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z0-9]Z[A-Z0-9]$",
    re.I,
)

def _compact_alnum_v3(value):
    return re.sub(r"[^A-Z0-9]", "", str(value).upper())

def recover_gstins_v3(records):
    found, seen = [], set()

    for i, rec in enumerate(records):
        for width in (1, 2, 3, 4):
            window = records[i:i + width]
            if len(window) != width:
                continue
            if any(item["page"] != rec["page"] for item in window):
                break

            compact = "".join(_compact_alnum_v3(item["word"]) for item in window)
            compact = re.sub(r"^(GSTIN|GSTNO|GSTNUMBER)", "", compact)

            if not _GSTIN_RE_V3.fullmatch(compact) or compact in seen:
                continue

            seen.add(compact)
            found.append({
                "value": compact,
                "page": rec["page"],
                "start_index": rec["index"],
                "end_index": window[-1]["index"],
            })
    return found


# 4) More tolerant GST component parser.
_TAX_KIND_RE_V3 = re.compile(r"(?i)(cgst|sgst|igst|gst|vat)")
_RATE_RE_V3 = re.compile(r"(?<!\d)(\d{1,2}(?:\.\d+)?)\s*%")

def recover_tax_components_v2(records):
    components = []

    for pos, rec in enumerate(records):
        text = str(rec["word"]).strip()
        norm = rec["norm"]

        if norm.startswith("gstin"):
            continue

        m_kind = _TAX_KIND_RE_V3.search(text) or _TAX_KIND_RE_V3.search(norm)
        if not m_kind:
            continue

        kind = m_kind.group(1).upper()

        candidates = []
        if "y" in rec:
            for cand in records[max(0, pos - 3): min(len(records), pos + 12)]:
                if cand["page"] != rec["page"]:
                    continue
                if "y" in cand and abs(float(cand["y"]) - float(rec["y"])) <= 5.5:
                    candidates.append(cand)

        if not candidates:
            candidates = [
                cand for cand in records[pos:min(len(records), pos + 12)]
                if cand["page"] == rec["page"]
            ]

        rate = None
        amount_candidates = []

        m_rate = _RATE_RE_V3.search(text)
        if m_rate:
            rate = float(m_rate.group(1))

        for cand in candidates:
            ctext = str(cand["word"]).strip()

            if rate is None:
                rm = _RATE_RE_V3.search(ctext)
                if rm:
                    rate = float(rm.group(1))
                    continue

            value = money_v2(ctext)
            if value is None:
                continue

            if rate is not None and abs(value - rate) <= 1e-9 and "%" in ctext:
                continue
            if 0 <= value <= 100 and "%" in ctext:
                if rate is None:
                    rate = value
                continue
            if re.fullmatch(r"\d{4}", ctext) and 1990 <= value <= 2100:
                continue

            amount_candidates.append((cand, value))

        if not amount_candidates:
            continue

        if "x" in rec and all("x" in c for c, _ in amount_candidates):
            after = [
                (c, v) for c, v in amount_candidates
                if float(c["x"]) >= float(rec["x"])
            ]
            pool = after or amount_candidates
            amount_rec, amount = max(pool, key=lambda item: float(item[0]["x"]))
        else:
            amount_rec, amount = amount_candidates[0]

        if amount <= 0:
            continue

        components.append({
            "type": kind,
            "rate_percent": rate,
            "amount": round(float(amount), 2),
            "page": rec["page"],
            "index": amount_rec["index"],
        })

    deduped, seen = [], set()
    for comp in components:
        key = (comp["type"], comp["rate_percent"], comp["amount"], comp["page"])
        if key not in seen:
            seen.add(key)
            deduped.append(comp)

    return deduped


# 5) Multi-row table recovery.
# V2's parser returned only one best qty*rate≈amount triplet.
_TABLE_HEADER_WORDS_V3 = {
    "description", "particulars", "product", "goods", "material",
}
_QTY_WORDS_V3 = {"qty", "quantity"}
_RATE_WORDS_V3 = {"rate", "price", "unitprice", "unitrate"}
_AMOUNT_WORDS_V3 = {"amt", "amount", "value", "netamount"}
_TABLE_STOP_V3 = {
    "subtotal", "gst", "cgst", "sgst", "igst", "tax",
    "grandtotal", "nettotal", "amountpayable", "remarks",
}

def _find_table_bounds_v3(records):
    header_pos = None
    header_end = None

    for pos, rec in enumerate(records):
        if rec["norm"] not in _TABLE_HEADER_WORDS_V3:
            continue

        nearby = records[max(0, pos - 4): min(len(records), pos + 24)]
        norms = {x["norm"] for x in nearby}

        if (
            norms & _QTY_WORDS_V3
            and norms & _RATE_WORDS_V3
            and norms & _AMOUNT_WORDS_V3
        ):
            header_pos = pos
            header_end = pos

            for j in range(pos, min(len(records), pos + 24)):
                n = records[j]["norm"]
                if (
                    n in _QTY_WORDS_V3
                    or n in _RATE_WORDS_V3
                    or n in _AMOUNT_WORDS_V3
                    or n in {"uom", "unit", "hsn", "sac", "code", "material"}
                ):
                    header_end = j
            break

    if header_pos is None:
        return None, None

    end = len(records)
    seen_numeric = False

    for j in range(header_end + 1, len(records)):
        n = records[j]["norm"]
        if money_v2(records[j]["word"]) is not None:
            seen_numeric = True

        if seen_numeric:
            if n in _TABLE_STOP_V3 or n == "total":
                end = j
                break

    return header_end + 1, end


def _valid_triplet_v3(q, r, a):
    qv, rv, av = q["value"], r["value"], a["value"]

    if qv <= 0 or rv < 0 or av < 0:
        return None

    qtext = str(q["record"]["word"])
    if qv >= 100000 and "." not in qtext:
        return None

    diff = abs(qv * rv - av)
    tol = max(0.05, abs(av) * 0.001)

    if diff > tol:
        return None

    return diff


def _build_item_v3(row_records, qty, rate, amount, diff):
    qrec = qty["record"]

    material_code = None
    for rec in row_records:
        text = str(rec["word"]).strip()
        if rec["index"] >= qrec["index"]:
            break
        compact = re.sub(r"[^0-9]", "", text)
        if re.fullmatch(r"\d{5,18}", compact):
            material_code = compact
            break

    description_tokens = []
    headerish = (
        _TABLE_HEADER_WORDS_V3 | _QTY_WORDS_V3 | _RATE_WORDS_V3 |
        _AMOUNT_WORDS_V3 | {"hsn", "sac", "uom", "unit", "code"}
    )

    for rec in row_records:
        if rec["index"] >= qrec["index"]:
            break

        text = str(rec["word"]).strip()

        if not text or rec["norm"] in headerish:
            continue
        if material_code and re.sub(r"[^0-9]", "", text) == material_code:
            continue
        if any(ch.isalpha() for ch in text):
            description_tokens.append(text)

    description = " ".join(description_tokens).strip() or NOT_DETECTED

    return {
        "material_code": material_code or NOT_DETECTED,
        "description": description,
        "uom": NOT_DETECTED,
        "quantity": str(qrec["word"]),
        "quantity_numeric": float(qty["value"]),
        "unit_price": round(float(rate["value"]), 2),
        "line_amount": round(float(amount["value"]), 2),
        "unit_price_source": "TABLE_ARITHMETIC_VALIDATED_V3",
        "line_amount_source": "TABLE_ARITHMETIC_VALIDATED_V3",
        "arithmetic_difference": round(float(diff), 6),
        "page": qrec["page"],
    }


def recover_simple_item_table_v2(records):
    start, end = _find_table_bounds_v3(records)

    if start is None:
        return []

    table = records[start:end]

    if not table:
        return []

    items = []
    has_geometry = any("y" in rec and "x" in rec for rec in table)

    # Native PDF: use visual rows.
    if has_geometry:
        by_page = {}

        for rec in table:
            if "y" in rec and "x" in rec:
                by_page.setdefault(rec["page"], []).append(rec)

        for page, page_records in by_page.items():
            page_records = sorted(
                page_records,
                key=lambda r: (float(r["y"]), float(r["x"])),
            )

            rows = []

            for rec in page_records:
                placed = False

                for row in rows:
                    if abs(float(rec["y"]) - row["y_mean"]) <= 4.5:
                        row["records"].append(rec)
                        row["y_mean"] = (
                            sum(float(x["y"]) for x in row["records"])
                            / len(row["records"])
                        )
                        placed = True
                        break

                if not placed:
                    rows.append({
                        "y_mean": float(rec["y"]),
                        "records": [rec],
                    })

            previous_text_row = []

            for row in rows:
                row_records = sorted(
                    row["records"],
                    key=lambda r: float(r["x"]),
                )

                numeric = []

                for p, rec in enumerate(row_records):
                    value = money_v2(rec["word"])
                    if value is not None:
                        numeric.append({
                            "position": p,
                            "record": rec,
                            "value": value,
                        })

                best = None

                for i in range(len(numeric)):
                    for j in range(i + 1, min(i + 5, len(numeric))):
                        for k in range(j + 1, min(j + 5, len(numeric))):
                            diff = _valid_triplet_v3(
                                numeric[i], numeric[j], numeric[k]
                            )

                            if diff is None:
                                continue

                            score = diff + 0.00001 * (
                                abs(
                                    numeric[j]["record"]["index"]
                                    - numeric[i]["record"]["index"]
                                )
                                + abs(
                                    numeric[k]["record"]["index"]
                                    - numeric[j]["record"]["index"]
                                )
                            )

                            if best is None or score < best["score"]:
                                best = {
                                    "q": numeric[i],
                                    "r": numeric[j],
                                    "a": numeric[k],
                                    "diff": diff,
                                    "score": score,
                                }

                if best:
                    full_row = previous_text_row + row_records
                    items.append(
                        _build_item_v3(
                            full_row,
                            best["q"],
                            best["r"],
                            best["a"],
                            best["diff"],
                        )
                    )
                    previous_text_row = []
                else:
                    if any(
                        any(ch.isalpha() for ch in str(r["word"]))
                        for r in row_records
                    ):
                        previous_text_row = row_records[-12:]
                    else:
                        previous_text_row = []

    # OCR/no geometry fallback: sequential non-overlapping triplets.
    if not items:
        numeric = []

        for pos, rec in enumerate(table):
            value = money_v2(rec["word"])

            if value is not None:
                numeric.append({
                    "position": pos,
                    "record": rec,
                    "value": value,
                })

        used_until = -1
        previous_boundary = 0

        for i in range(len(numeric)):
            q = numeric[i]

            if q["position"] <= used_until:
                continue

            best = None

            for j in range(i + 1, min(i + 5, len(numeric))):
                r = numeric[j]

                for k in range(j + 1, min(j + 5, len(numeric))):
                    a = numeric[k]
                    diff = _valid_triplet_v3(q, r, a)

                    if diff is None:
                        continue

                    score = diff + 0.0001 * (a["position"] - q["position"])

                    if best is None or score < best["score"]:
                        best = {
                            "q": q,
                            "r": r,
                            "a": a,
                            "diff": diff,
                            "score": score,
                        }

            if best is None:
                continue

            row_start = previous_boundary
            row_end = best["a"]["position"] + 1
            row_records = table[row_start:row_end]

            items.append(
                _build_item_v3(
                    row_records,
                    best["q"],
                    best["r"],
                    best["a"],
                    best["diff"],
                )
            )

            used_until = best["a"]["position"]
            previous_boundary = used_until + 1

    clean, seen = [], set()

    for item in items:
        key = (
            item["page"],
            round(item["quantity_numeric"], 6),
            round(item["unit_price"], 2),
            round(item["line_amount"], 2),
            item["material_code"],
        )

        if key not in seen:
            seen.add(key)
            clean.append(item)

    return clean


# 6) Refresh final result after all recoveries.
def _norm_party_v3(value):
    return re.sub(r"[^a-z0-9]+", "", str(value).lower())

def _party_similarity_v3(a, b):
    aa, bb = _norm_party_v3(a), _norm_party_v3(b)
    if not aa or not bb:
        return 0.0
    return SequenceMatcher(None, aa, bb).ratio()


def _refresh_v3(input_path, result):
    result = copy.deepcopy(result)
    records = quality_records_v2(input_path)
    fields = result["fields"]

    # GSTIN candidates.
    gstins = recover_gstins_v3(records)
    result.setdefault("identifiers", {})["gstin_candidates"] = gstins

    # GST components/tax total.
    comps = recover_tax_components_v2(records)

    if comps:
        tax_total = round(sum(c["amount"] for c in comps), 2)

        fields["TAX"] = {
            "value": format_money_v2(tax_total),
            "status": "RECONCILED",
            "source": "GST_COMPONENT_RECONCILIATION_V3",
        }

        result.setdefault("tax_details", {})["gst_components"] = comps
        result["tax_details"]["total_tax"] = tax_total

    # Multi-row line items.
    items = recover_simple_item_table_v2(records)

    if items:
        result["line_items"] = []

        for n, item in enumerate(items, 1):
            result["line_items"].append({
                "line_number": n,
                "material_code": item["material_code"],
                "description": item["description"],
                "hsn_code": NOT_DETECTED,
                "uom": item["uom"],
                "quantity": item["quantity"],
                "quantity_numeric": item["quantity_numeric"],
                "unit_price": item["unit_price"],
                "unit_price_source": item["unit_price_source"],
                "line_amount": item["line_amount"],
                "line_amount_source": item["line_amount_source"],
                "page": item["page"],
            })

        fields["LINE_ITEM_DESC"] = {
            "value": [x["description"] for x in items],
            "status": "RULE_RECOVERED",
            "source": "MULTI_ROW_TABLE_V3",
        }
        fields["LINE_ITEM_QTY"] = {
            "value": [x["quantity"] for x in items],
            "status": "RULE_RECOVERED",
            "source": "MULTI_ROW_TABLE_V3",
        }
        fields["LINE_ITEM_UNIT_PRICE"] = {
            "value": [format_money_v2(x["unit_price"]) for x in items],
            "status": "RULE_RECOVERED",
            "source": "TABLE_ARITHMETIC_VALIDATED_V3",
        }
        fields["LINE_ITEM_AMOUNT"] = {
            "value": [format_money_v2(x["line_amount"]) for x in items],
            "status": "RULE_RECOVERED",
            "source": "TABLE_ARITHMETIC_VALIDATED_V3",
        }


    # If the currently selected total conflicts with explicit invoice arithmetic,
    # try another explicit total-anchor candidate rather than inventing a value.
    provisional_subtotal = money_v2(fields["SUBTOTAL"]["value"])
    provisional_tax = money_v2(fields["TAX"]["value"])
    provisional_discount = money_v2(fields["DISCOUNT"]["value"])

    if provisional_subtotal is not None:
        expected_total = provisional_subtotal
        if provisional_tax is not None:
            expected_total += provisional_tax
        if provisional_discount is not None:
            expected_total -= provisional_discount
        expected_total = round(expected_total, 2)

        total_candidates = _total_anchor_candidates_v3(
            records,
            include_generic=True,
        )

        if total_candidates:
            best_total = min(
                total_candidates,
                key=lambda c: abs(c["value"] - expected_total),
            )
            tolerance = max(0.05, abs(expected_total) * 0.001)

            if abs(best_total["value"] - expected_total) <= tolerance:
                fields["TOTAL_AMOUNT"] = {
                    "value": format_money_v2(best_total["value"]),
                    "status": "RECONCILED",
                    "source": "FINANCIAL_TOTAL_RECONCILIATION_V3",
                }


    # Normalize financials.
    result.setdefault("normalized", {})

    for field_name, norm_name in [
        ("SUBTOTAL", "subtotal"),
        ("TAX", "tax"),
        ("DISCOUNT", "discount"),
        ("TOTAL_AMOUNT", "total_amount"),
    ]:
        result["normalized"][norm_name] = money_v2(
            fields[field_name]["value"]
        )

    subtotal = result["normalized"].get("subtotal")
    tax = result["normalized"].get("tax")
    discount = result["normalized"].get("discount")
    total = result["normalized"].get("total_amount")

    calc = None
    diff = None
    financial_pass = None

    if subtotal is not None and total is not None:
        calc = subtotal

        if tax is not None:
            calc += tax

        if discount is not None:
            calc -= discount

        calc = round(calc, 2)
        diff = round(abs(calc - total), 2)
        financial_pass = diff <= 0.05

    result.setdefault("validation", {})["financial_reconciliation"] = {
        "subtotal": subtotal,
        "tax": tax,
        "discount": discount,
        "total_amount": total,
        "calculated_total": calc,
        "difference": diff,
        "passed": financial_pass,
    }

    # GST reconciliation.
    comp_sum = None
    gst_diff = None
    gst_match = None

    if comps:
        comp_sum = round(sum(c["amount"] for c in comps), 2)

        if tax is not None:
            gst_diff = round(abs(comp_sum - tax), 2)
            gst_match = gst_diff <= 0.05

    result["validation"]["gst_reconciliation"] = {
        "component_sum": comp_sum,
        "matches_tax_total": gst_match,
        "difference": gst_diff,
    }

    # Line reconciliation.
    line_items = result.get("line_items", [])
    amounts = [
        x.get("line_amount")
        for x in line_items
        if x.get("line_amount") is not None
    ]
    quantities = [
        x.get("quantity_numeric")
        for x in line_items
        if x.get("quantity_numeric") is not None
    ]

    line_sum = (
        round(sum(amounts), 2)
        if amounts and len(amounts) == len(line_items)
        else None
    )
    line_diff = (
        round(abs(line_sum - subtotal), 2)
        if line_sum is not None and subtotal is not None
        else None
    )
    line_match = (
        line_diff <= 0.05
        if line_diff is not None
        else None
    )

    result["validation"]["line_item_reconciliation"] = {
        "row_count": len(line_items),
        "total_quantity": sum(quantities) if quantities else None,
        "line_amount_sum": line_sum,
        "matches_subtotal": line_match,
        "difference": line_diff,
    }

    # Customer/vendor overlap is flagged, not silently overwritten.
    vendor = fields["VENDOR_NAME"]["value"]
    customer = fields["CUSTOMER_NAME"]["value"]
    party_similarity = 0.0

    if vendor != NOT_DETECTED and customer != NOT_DETECTED:
        party_similarity = _party_similarity_v3(vendor, customer)

    core = [
        "VENDOR_NAME",
        "INVOICE_NUMBER",
        "INVOICE_DATE",
        "CUSTOMER_NAME",
        "CURRENCY",
        "TOTAL_AMOUNT",
    ]

    missing_core = [
        field for field in core
        if fields[field]["value"] in {None, "", NOT_DETECTED}
    ]

    result["validation"]["core_fields_pass"] = not missing_core
    result["validation"]["missing_core_fields"] = missing_core

    quality_flags = []

    if financial_pass is False:
        quality_flags.append("FINANCIAL_RECONCILIATION_FAILED")
    if line_match is False:
        quality_flags.append("LINE_ITEM_RECONCILIATION_FAILED")
    if comps and gst_match is False:
        quality_flags.append("GST_RECONCILIATION_FAILED")
    if party_similarity >= 0.82:
        quality_flags.append("CUSTOMER_VENDOR_OVERLAP_REVIEW")
    if missing_core:
        quality_flags.append("CORE_FIELDS_MISSING")

    result["validation"]["quality_flags"] = quality_flags

    # Refresh stale warnings using the FINAL values.
    missing_all = [
        field for field in TARGET_FIELDS
        if fields[field]["value"] in {None, "", NOT_DETECTED}
    ]

    warnings = [
        f"{field} was not detected."
        for field in missing_all
    ]

    if party_similarity >= 0.82:
        warnings.append(
            "CUSTOMER_NAME is very similar to VENDOR_NAME; "
            "verify the buyer/consignee block."
        )

    result["validation"]["warnings"] = warnings

    # Missing optional terms alone should not force review.
    review = (
        bool(missing_core)
        or financial_pass is False
        or line_match is False
        or (bool(comps) and gst_match is False)
        or party_similarity >= 0.82
    )

    overall = "REVIEW_REQUIRED" if review else "PASS"

    result["validation"]["overall_status"] = overall
    result["document"]["status"] = overall

    resolved = [
        field for field in TARGET_FIELDS
        if fields[field]["value"] not in {None, "", NOT_DETECTED}
    ]
    missing = [
        field for field in TARGET_FIELDS
        if field not in resolved
    ]
    neural = [
        field for field in TARGET_FIELDS
        if fields[field].get("source") == "NEURAL"
    ]
    recovered = [
        field for field in resolved
        if field not in neural
    ]

    result["extraction_summary"] = {
        "target_field_count": len(TARGET_FIELDS),
        "resolved_field_count": len(resolved),
        "undetected_field_count": len(missing),
        "resolved_fields": resolved,
        "undetected_fields": missing,
        "neural_fields": neural,
        "recovered_or_reconciled_fields": recovered,
    }

    return result


# 7) Final canonical entry point.
def process_invoice_v3(input_path, verbose=True):
    result = process_invoice_v2(input_path, verbose=False)
    result = _refresh_v3(input_path, result)

    document_id = result["document"]["document_id"]
    output_path = (
        PROD_OUTPUT_ROOT
        / f"{document_id}_invoice_extraction.json"
    )

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(
            result,
            f,
            indent=2,
            ensure_ascii=False,
        )

    if verbose:
        print("\n" + "=" * 88)
        print("🔥 PRODUCTION V3 RESULT 🔥")
        print("=" * 88)

        for field in TARGET_FIELDS:
            fd = result["fields"][field]
            print(f"{field:<24}: {fd['value']}")
            print(f"{'':24}  source = {fd.get('source')}")

        print("\nLINE ITEMS")

        if result.get("line_items"):
            for item in result["line_items"]:
                print(f"\n  LINE {item['line_number']}")
                print("    Material:", item["material_code"])
                print("    Desc    :", item["description"])
                print("    Qty     :", item["quantity"])
                print("    Rate    :", item["unit_price"])
                print("    Amount  :", item["line_amount"])
        else:
            print("  NOT_DETECTED")

        v = result["validation"]
        s = result["extraction_summary"]

        print("\nVALIDATION")
        print("  Core      :", v["core_fields_pass"])
        print("  Financial :", v["financial_reconciliation"]["passed"])
        print("  GST       :", v["gst_reconciliation"]["matches_tax_total"])
        print("  Line      :", v["line_item_reconciliation"]["matches_subtotal"])
        print("  Flags     :", v["quality_flags"])

        print("\nSUMMARY")
        print(
            "  Resolved  :",
            f"{s['resolved_field_count']}/{s['target_field_count']}",
        )
        print("  Missing   :", s["undetected_fields"])
        print("  Overall   :", v["overall_status"])
        print("\nOutput:", output_path)

    return result


process_invoice_final = process_invoice_v3

print("\n✅ HOTFIX READY")
print("No retraining. No model reload.")
print("Rerun only the invoice-upload cell.")
print("=" * 88)
