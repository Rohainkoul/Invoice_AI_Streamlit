# ============================================================
# Invoice AI V2 — Runtime Hotfix V5
# Apply AFTER V4. No model reload. No retraining.
#
# Generic fixes based on document-layout evidence:
# - Associates INVOICE_DATE with the invoice/bill-number row.
# - Recovers explicit ROUND OFF and uses it in reconciliation.
# - Treats CUSTOMER_NAME as not-present when there is no buyer/customer block.
# - Uses evidence-aware required fields (missing optional fields do not fail a good invoice).
# - Uses invoice number as stable document_id instead of Colab "(5)" filenames.
# ============================================================

import re
from datetime import datetime

assert "_refresh_v3" in globals(), "Run V4 first."
assert "process_invoice_v3" in globals(), "Run V4 first."
assert "quality_records_v2" in globals(), "Run the production/V3/V4 cells first."

if "_refresh_v3_before_v5" not in globals():
    _refresh_v3_before_v5 = _refresh_v3


_DATE_RE_V5 = re.compile(
    r"^(?:"
    r"\d{1,2}[./-]\d{1,2}[./-]\d{2,4}"
    r"|"
    r"\d{4}[./-]\d{1,2}[./-]\d{1,2}"
    r")$"
)

_DATE_FORMATS_V5 = (
    "%d.%m.%Y", "%d/%m/%Y", "%d-%m-%Y",
    "%d.%m.%y", "%d/%m/%y", "%d-%m-%y",
    "%Y.%m.%d", "%Y/%m/%d", "%Y-%m-%d",
)


def _clean_scalar_v5(value):
    return str(value).strip(" \t\r\n:;,|")


def _date_normalized_v5(value):
    text = _clean_scalar_v5(value)

    for fmt in _DATE_FORMATS_V5:
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass

    return None


def _invoice_number_record_v5(records, invoice_number):
    target = re.sub(r"[^A-Z0-9]", "", str(invoice_number).upper())

    if not target:
        return None

    # Exact one-token match first.
    for rec in records:
        compact = re.sub(r"[^A-Z0-9]", "", str(rec["word"]).upper())
        if compact == target:
            return rec

    # Fallback for PDF/OCR splitting the number over 2–3 tokens.
    for i, rec in enumerate(records):
        for width in (2, 3):
            window = records[i:i + width]

            if len(window) != width:
                continue

            if any(x["page"] != rec["page"] for x in window):
                break

            compact = "".join(
                re.sub(r"[^A-Z0-9]", "", str(x["word"]).upper())
                for x in window
            )

            if compact == target:
                merged = dict(rec)

                if all(x.get("y") is not None for x in window):
                    merged["y"] = sum(float(x["y"]) for x in window) / len(window)

                if all(x.get("x") is not None for x in window):
                    merged["x"] = sum(float(x["x"]) for x in window) / len(window)

                return merged

    return None


def _invoice_date_same_row_v5(records, invoice_number):
    """
    Generic header association:
    choose a date on the same visual row as the extracted invoice/bill number.
    This prevents a REF NO date on the next row from becoming INVOICE_DATE.
    """
    inv_rec = _invoice_number_record_v5(records, invoice_number)

    if inv_rec is None or inv_rec.get("y") is None:
        return None

    candidates = []

    for rec in records:
        if rec["page"] != inv_rec["page"]:
            continue

        text = _clean_scalar_v5(rec["word"])

        if not _DATE_RE_V5.fullmatch(text):
            continue

        if rec.get("y") is None:
            continue

        dy = abs(float(rec["y"]) - float(inv_rec["y"]))

        # Same visual line/row.
        if dy > 5.5:
            continue

        right_penalty = 0.0

        if inv_rec.get("x") is not None and rec.get("x") is not None:
            if float(rec["x"]) < float(inv_rec["x"]):
                right_penalty = 25.0

        candidates.append({
            "value": text,
            "normalized": _date_normalized_v5(text),
            "page": rec["page"],
            "index": rec["index"],
            "dy": dy,
            "score": dy + right_penalty,
        })

    if not candidates:
        return None

    return min(candidates, key=lambda x: x["score"])


def _parse_signed_money_v5(value):
    text = str(value).strip()
    negative = False

    if text.endswith("-"):
        negative = True
        text = text[:-1].strip()

    if text.startswith("-"):
        negative = True
        text = text[1:].strip()

    text = (
        text.replace(",", "")
        .replace("₹", "")
        .replace("$", "")
        .strip()
    )

    if not re.fullmatch(r"\d+(?:\.\d+)?", text):
        return None

    number = float(text)

    return -number if negative else number


def _round_off_v5(records):
    """
    Recover an explicit ROUND OFF / ROUNDING value from the same visual row.
    """
    for i, rec in enumerate(records):
        if rec["norm"] != "round":
            continue

        following = records[i + 1:i + 5]
        norms = [x["norm"] for x in following]

        if "off" not in norms and "roundoff" not in norms:
            continue

        if rec.get("y") is None:
            continue

        same_row = [
            x for x in records
            if (
                x["page"] == rec["page"]
                and x.get("y") is not None
                and abs(float(x["y"]) - float(rec["y"])) <= 5.5
            )
        ]

        money = []

        for candidate in same_row:
            value = _parse_signed_money_v5(candidate["word"])

            if value is not None:
                money.append((candidate, value))

        if not money:
            continue

        # Right-most number on ROUND OFF row is normally the adjustment.
        if all(x[0].get("x") is not None for x in money):
            chosen, value = max(money, key=lambda x: float(x[0]["x"]))
        else:
            chosen, value = money[-1]

        # Some invoices print "ROUND OFF 0.30-" meaning negative 0.30.
        return {
            "value": round(float(value), 2),
            "raw": str(chosen["word"]),
            "page": chosen["page"],
            "index": chosen["index"],
            "source": "ROUND_OFF_ROW_V5",
        }

    return None


def _has_phrase_v5(records, phrase):
    try:
        return bool(phrase_hits_v2(records, phrase))
    except Exception:
        norms = [r["norm"] for r in records]
        target = list(phrase)

        for i in range(0, len(norms) - len(target) + 1):
            if norms[i:i + len(target)] == target:
                return True

        return False


def _customer_expected_v5(records):
    """
    A customer name is required only when the document contains an explicit
    buyer/customer/consignee party block. Generic legal terms mentioning
    'buyer' do not count.
    """
    strong = (
        ("bill", "to"),
        ("billed", "to"),
        ("customer", "name"),
        ("buyer", "name"),
        ("consignee", "name"),
        ("sold", "to"),
        ("ship", "to"),
    )

    return any(_has_phrase_v5(records, phrase) for phrase in strong)


def _missing_v5(value):
    if value is None:
        return True

    if isinstance(value, str):
        return value.strip() in {"", NOT_DETECTED}

    if isinstance(value, (list, tuple)):
        return len(value) == 0

    return False


def _refresh_v3(input_path, result):
    out = _refresh_v3_before_v5(input_path, result)

    fields = out["fields"]
    validation = out["validation"]
    records = quality_records_v2(input_path)

    # --------------------------------------------------------
    # 1) Correct invoice date by invoice-number/header row.
    # --------------------------------------------------------
    invoice_number = fields["INVOICE_NUMBER"]["value"]

    if not _missing_v5(invoice_number):
        row_date = _invoice_date_same_row_v5(
            records,
            invoice_number,
        )

        if row_date and row_date["normalized"]:
            fields["INVOICE_DATE"] = {
                "value": row_date["value"],
                "status": "RULE_RECOVERED",
                "source": "INVOICE_NUMBER_ROW_DATE_V5",
            }

            out.setdefault("normalized", {})[
                "invoice_date"
            ] = row_date["normalized"]

    # --------------------------------------------------------
    # 2) Explicit round-off and exact financial reconciliation.
    # --------------------------------------------------------
    round_off = _round_off_v5(records)

    financial_details = out.setdefault(
        "financial_details",
        {},
    )

    if round_off is not None:
        financial_details["round_off"] = round_off

    subtotal = money_v2(fields["SUBTOTAL"]["value"])
    tax = money_v2(fields["TAX"]["value"])
    discount = money_v2(fields["DISCOUNT"]["value"])
    total = money_v2(fields["TOTAL_AMOUNT"]["value"])

    calculated = None
    difference = None
    passed = None

    if subtotal is not None and total is not None:
        calculated = float(subtotal)

        if tax is not None:
            calculated += float(tax)

        if discount is not None:
            calculated -= float(discount)

        if round_off is not None:
            calculated += float(round_off["value"])

        calculated = round(calculated, 2)
        difference = round(abs(calculated - float(total)), 2)
        passed = difference <= 0.05

    validation["financial_reconciliation"] = {
        "subtotal": subtotal,
        "tax": tax,
        "discount": discount,
        "round_off": (
            round_off["value"]
            if round_off is not None
            else None
        ),
        "total_amount": total,
        "calculated_total": calculated,
        "difference": difference,
        "passed": passed,
    }

    # --------------------------------------------------------
    # 3) Evidence-aware presence/required-field logic.
    # --------------------------------------------------------
    customer_expected = _customer_expected_v5(records)

    not_present_fields = []

    if (
        _missing_v5(fields["CUSTOMER_NAME"]["value"])
        and not customer_expected
    ):
        fields["CUSTOMER_NAME"] = {
            "value": NOT_DETECTED,
            "status": "NOT_PRESENT",
            "source": "NO_CUSTOMER_BLOCK_EVIDENCE_V5",
        }
        not_present_fields.append("CUSTOMER_NAME")

    # These target fields are optional when their label/evidence is absent.
    # V4 already rejects false TAX. Do not convert absent values into guesses.
    optional_absence_checks = {
        "DUE_DATE": (
            ("due", "date"),
            ("payment", "due"),
        ),
        "DISCOUNT": (
            ("discount",),
            ("disc",),
        ),
        "PAYMENT_TERMS": (
            ("payment", "terms"),
            ("credit", "terms"),
        ),
        "TAX": (
            ("cgst",),
            ("sgst",),
            ("igst",),
            ("tax", "amount"),
            ("gst", "amount"),
        ),
    }

    for field, phrases in optional_absence_checks.items():
        if not _missing_v5(fields[field]["value"]):
            continue

        evidence = any(
            _has_phrase_v5(records, phrase)
            for phrase in phrases
        )

        if not evidence and field not in not_present_fields:
            fields[field]["status"] = "NOT_PRESENT"
            if fields[field].get("source") == "NOT_DETECTED":
                fields[field]["source"] = "NO_FIELD_EVIDENCE_V5"
            not_present_fields.append(field)

    # Stable document ID: invoice number, not Colab's "(5)" upload filename.
    if not _missing_v5(invoice_number):
        out["document"]["document_id"] = re.sub(
            r"[^A-Za-z0-9._-]+",
            "_",
            str(invoice_number),
        )

    # Required core fields.
    required_core = [
        "VENDOR_NAME",
        "INVOICE_NUMBER",
        "INVOICE_DATE",
        "CURRENCY",
        "TOTAL_AMOUNT",
    ]

    if customer_expected:
        required_core.append("CUSTOMER_NAME")

    missing_core = [
        field
        for field in required_core
        if _missing_v5(fields[field]["value"])
    ]

    validation["required_core_fields"] = required_core
    validation["missing_core_fields"] = missing_core
    validation["core_fields_pass"] = not missing_core
    validation["not_present_fields"] = sorted(
        set(not_present_fields)
    )

    # --------------------------------------------------------
    # 4) Refresh warnings, quality flags and overall status.
    # --------------------------------------------------------
    line_pass = (
        validation
        .get("line_item_reconciliation", {})
        .get("matches_subtotal")
    )

    gst_components = (
        out.get("tax_details", {})
        .get("gst_components", [])
        or []
    )

    gst_pass = (
        validation
        .get("gst_reconciliation", {})
        .get("matches_tax_total")
    )

    flags = []

    if missing_core:
        flags.append("CORE_FIELDS_MISSING")

    if passed is False:
        flags.append("FINANCIAL_RECONCILIATION_FAILED")

    if line_pass is False:
        flags.append("LINE_ITEM_RECONCILIATION_FAILED")

    if gst_components and gst_pass is False:
        flags.append("GST_RECONCILIATION_FAILED")

    # Keep informational false-positive rejection flag.
    if (
        fields["TAX"].get("source")
        == "REJECTED_QUANTITY_FALSE_POSITIVE_V4"
    ):
        flags.append("TAX_FALSE_POSITIVE_REJECTED")

    validation["quality_flags"] = flags

    warnings = []

    for field in TARGET_FIELDS:
        if not _missing_v5(fields[field]["value"]):
            continue

        if field in not_present_fields:
            warnings.append(
                f"{field} has no explicit evidence in the document; "
                "kept as NOT_DETECTED."
            )
        else:
            warnings.append(
                f"{field} was expected but not detected."
            )

    validation["warnings"] = warnings

    review_required = (
        bool(missing_core)
        or passed is False
        or line_pass is False
        or (bool(gst_components) and gst_pass is False)
    )

    overall = (
        "REVIEW_REQUIRED"
        if review_required
        else "PASS"
    )

    validation["overall_status"] = overall
    out["document"]["status"] = overall

    resolved = [
        field
        for field in TARGET_FIELDS
        if not _missing_v5(fields[field]["value"])
    ]

    unresolved = [
        field
        for field in TARGET_FIELDS
        if _missing_v5(fields[field]["value"])
        and field not in not_present_fields
    ]

    out["extraction_summary"] = {
        "target_field_count": len(TARGET_FIELDS),
        "resolved_field_count": len(resolved),
        "resolved_fields": resolved,
        "not_present_fields": sorted(set(not_present_fields)),
        "unresolved_expected_fields": unresolved,
        "required_core_fields": required_core,
        "missing_core_fields": missing_core,
    }

    return out


# process_invoice_v3 looks up _refresh_v3 dynamically.
process_invoice_final = process_invoice_v3

print("=" * 88)
print("🔥 RUNTIME HOTFIX V5 READY 🔥")
print("✅ Invoice-date/header-row association")
print("✅ Explicit round-off reconciliation")
print("✅ Evidence-aware customer/optional fields")
print("✅ Stable invoice-number document ID")
print("No retraining. No model reload.")
print("Rerun only the invoice-upload cell.")
print("=" * 88)
