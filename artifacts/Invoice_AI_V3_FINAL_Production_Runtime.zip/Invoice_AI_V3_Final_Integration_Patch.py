
# ============================================================
# INVOICE AI V3 — FINAL PRODUCTION INTEGRATION PATCH
#
# Applied AFTER verified V6.1 runtime stack.
#
# NO MODEL RELOAD
# NO PROCESSOR RELOAD
# NO TRAINING
# ============================================================

from pathlib import Path
from difflib import SequenceMatcher

import copy
import json
import re


# ============================================================
# 0. VERIFY BASE RUNTIME
# ============================================================

_required = [

    "MODEL",
    "PROCESSOR",

    "TARGET_FIELDS",

    "_refresh_v3_before_v4",

    "_v6_apply_overlay",

    "_v6_native_pages",

    "_v6_set_field",

    "_v6_missing",

    "_v6_rightmost_amount",

    "_v6_gst_type",

    "_v6_gst_candidates",

    "_v6_select_gst_components",

    "_v6_format_money",

    "_v6_vendor_address",

    "NOT_DETECTED",
]


_missing = [

    name

    for name in _required

    if name not in globals()
]


if _missing:

    raise RuntimeError(
        "Final V3 patch missing runtime globals: "
        + ", ".join(_missing)
    )


# ============================================================
# 1. FINAL V3 PRODUCTION PATHS
# ============================================================

PROD_ROOT = Path(
    "/content/Invoice_AI_V3_Production"
)


PROD_WORK_ROOT = (

    PROD_ROOT

    /

    "inference_work"
)


PROD_OUTPUT_ROOT = (

    PROD_ROOT

    /

    "inference_outputs"
)


PROD_WORK_ROOT.mkdir(
    parents=True,
    exist_ok=True
)


PROD_OUTPUT_ROOT.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# 2. EXACT FINAL FIELD SCHEMA
# ============================================================

_FINAL_ALL_FIELDS = list(
    TARGET_FIELDS
)


_FINAL_REPEAT_FIELDS = {

    "LINE_ITEM_DESC",

    "LINE_ITEM_QTY",

    "LINE_ITEM_UNIT_PRICE",

    "LINE_ITEM_AMOUNT",
}


_FINAL_SCALAR_FIELDS = [

    field

    for field in _FINAL_ALL_FIELDS

    if field not in _FINAL_REPEAT_FIELDS
]


assert len(
    _FINAL_ALL_FIELDS
) == 16


assert len(
    _FINAL_SCALAR_FIELDS
) == 12


def _final_missing_value(
    value,
):

    if value is None:

        return True


    if isinstance(
        value,
        str,
    ):

        return (
            value.strip()
            in {
                "",
                NOT_DETECTED,
            }
        )


    if isinstance(
        value,
        (
            list,
            tuple,
        ),
    ):

        return len(
            value
        ) == 0


    return False


# ============================================================
# 3. PERMANENT V3 LIST-SAFE REFRESH
# ============================================================

_FINAL_LEGACY_V3_REFRESH = (
    _refresh_v3_before_v4
)


def _final_v3_refresh_list_safe(
    input_path,
    result,
):

    global TARGET_FIELDS


    original_target_fields = (
        TARGET_FIELDS
    )


    try:

        # Old V3 contains unsafe set-membership checks.
        # Keep its summary loops scalar-only.
        TARGET_FIELDS = list(
            _FINAL_SCALAR_FIELDS
        )


        output = (
            _FINAL_LEGACY_V3_REFRESH(

                input_path,

                result,
            )
        )


    finally:

        TARGET_FIELDS = (
            original_target_fields
        )


    fields = output.setdefault(
        "fields",
        {}
    )


    for field in _FINAL_ALL_FIELDS:

        if field not in fields:

            fields[field] = {

                "value":
                    NOT_DETECTED,

                "status":
                    "NOT_DETECTED",

                "source":
                    "NOT_DETECTED",
            }


    resolved = [

        field

        for field in _FINAL_ALL_FIELDS

        if not _final_missing_value(

            fields[
                field
            ].get(
                "value"
            )
        )
    ]


    missing = [

        field

        for field in _FINAL_ALL_FIELDS

        if field not in resolved
    ]


    neural = [

        field

        for field in resolved

        if fields[
            field
        ].get(
            "source"
        )
        ==
        "NEURAL"
    ]


    recovered = [

        field

        for field in resolved

        if field not in neural
    ]


    output[
        "extraction_summary"
    ] = {

        "target_field_count":
            16,

        "resolved_field_count":
            len(
                resolved
            ),

        "undetected_field_count":
            len(
                missing
            ),

        "resolved_fields":
            resolved,

        "undetected_fields":
            missing,

        "neural_fields":
            neural,

        "recovered_or_reconciled_fields":
            recovered,
    }


    return output


_refresh_v3_before_v4 = (
    _final_v3_refresh_list_safe
)


# ============================================================
# 4. NATIVE/OCR PAGE CACHE
# ============================================================

_FINAL_NATIVE_PAGES_ORIGINAL = (
    _v6_native_pages
)


_FINAL_PAGE_CACHE = {}


def _final_cached_native_pages(
    input_path,
):

    input_path = Path(
        input_path
    )


    try:

        stat = input_path.stat()


        key = (

            str(
                input_path.resolve()
            ),

            int(
                stat.st_size
            ),

            int(
                stat.st_mtime_ns
            ),
        )


    except Exception:

        key = (
            str(
                input_path
            ),
        )


    if key not in _FINAL_PAGE_CACHE:

        _FINAL_PAGE_CACHE[
            key
        ] = (
            _FINAL_NATIVE_PAGES_ORIGINAL(
                input_path
            )
        )


    return _FINAL_PAGE_CACHE[
        key
    ]


_v6_native_pages = (
    _final_cached_native_pages
)


# ============================================================
# 5. GST COMPONENT CLOSENESS GUARD
# ============================================================

_FINAL_GST_SELECTOR_ORIGINAL = (
    _v6_select_gst_components
)


def _final_select_gst_components(
    candidates,
    expected_tax,
):

    selected = (
        _FINAL_GST_SELECTOR_ORIGINAL(

            candidates,

            expected_tax,
        )
    )


    if (
        not selected

        or

        expected_tax is None
    ):

        return selected


    try:

        expected = float(
            expected_tax
        )


        selected_total = round(

            sum(

                float(
                    item[
                        "amount"
                    ]
                )

                for item
                in selected
            ),

            2,
        )


    except Exception:

        return []


    if (
        abs(
            selected_total
            -
            expected
        )
        >
        0.05
    ):

        return []


    return selected


_v6_select_gst_components = (
    _final_select_gst_components
)


# ============================================================
# 6. GL-ACCOUNT BASE SUBTOTAL
# ============================================================

def _final_gl_base_subtotal(
    pages,
):

    candidates = []


    for page in pages:

        rows = page.get(
            "rows",
            []
        )


        header_end = None


        for index, row in enumerate(
            rows
        ):

            current = str(

                row.get(
                    "text",
                    ""
                )

            ).lower()


            previous = (

                str(

                    rows[
                        index - 1
                    ].get(
                        "text",
                        ""
                    )

                ).lower()

                if index > 0

                else ""
            )


            following = (

                str(

                    rows[
                        index + 1
                    ].get(
                        "text",
                        ""
                    )

                ).lower()

                if (
                    index + 1
                    <
                    len(rows)
                )

                else ""
            )


            current_has_gl = (

                "gl account"
                in current

                and

                (
                    "gl details"
                    in current

                    or

                    "details"
                    in current
                )
            )


            following_has_gl = (

                "gl account"
                in following

                and

                (
                    "gl details"
                    in following

                    or

                    "details"
                    in following
                )
            )


            if (
                current_has_gl

                and

                "amount"
                in current
            ):

                header_end = index

                break


            if (
                current_has_gl

                and

                "amount"
                in previous
            ):

                header_end = index

                break


            if (
                "amount"
                in current

                and

                following_has_gl
            ):

                header_end = (
                    index + 1
                )

                break


        if header_end is None:

            continue


        for row in rows[
            header_end + 1:
        ]:

            text = str(

                row.get(
                    "text",
                    ""
                )

            ).strip()


            lower = text.lower()


            if not text:

                continue


            if (
                "material description"
                in lower

                or

                "amount in words"
                in lower

                or

                "total value in words"
                in lower
            ):

                break


            if (
                _v6_gst_type(
                    text
                )
                is not None
            ):

                continue


            if not re.search(
                r"\b\d{6,10}\b",
                text,
            ):

                continue


            amount = (
                _v6_rightmost_amount(
                    row
                )
            )


            if amount is None:

                continue


            amount = float(
                amount
            )


            if amount <= 0:

                continue


            candidates.append(
                {
                    "amount":
                        amount,

                    "page":
                        page.get(
                            "page"
                        ),

                    "row_text":
                        text,
                }
            )


    if not candidates:

        return None


    return max(

        candidates,

        key=lambda item:
            item[
                "amount"
            ],
    )


# ============================================================
# 7. AMOUNT-IN-WORDS TOTAL
# ============================================================

def _final_amount_words_total(
    pages,
):

    candidates = []


    currency_words = (

        "rupee",
        "rupees",
        "inr",

        "dollar",
        "dollars",
        "usd",

        "euro",
        "euros",
        "eur",

        "pound",
        "pounds",
        "gbp",
    )


    for page in pages:

        for row in page.get(
            "rows",
            []
        ):

            text = str(

                row.get(
                    "text",
                    ""
                )

            ).strip()


            lower = text.lower()


            strong_context = (

                "amount in words"
                in lower

                or

                "total value in words"
                in lower

                or

                (
                    "only"
                    in lower

                    and

                    any(

                        word
                        in lower

                        for word
                        in currency_words
                    )
                )
            )


            if not strong_context:

                continue


            amount = (
                _v6_rightmost_amount(
                    row
                )
            )


            if amount is None:

                continue


            amount = float(
                amount
            )


            if amount <= 0:

                continue


            candidates.append(
                {
                    "amount":
                        amount,

                    "page":
                        page.get(
                            "page"
                        ),

                    "row_text":
                        text,
                }
            )


    if not candidates:

        return None


    return max(

        candidates,

        key=lambda item:
            item[
                "amount"
            ],
    )


# ============================================================
# 8. STRICT FINANCIAL PAIR CONFIRMATION
# ============================================================

def _final_confirm_financial_pair(
    pages,
    subtotal,
    total,
):

    if (
        subtotal is None

        or

        total is None
    ):

        return None


    subtotal = float(
        subtotal
    )


    total = float(
        total
    )


    if total <= subtotal:

        return None


    expected_tax = round(

        total
        -
        subtotal,

        2,
    )


    if expected_tax <= 0.05:

        return None


    candidates = (
        _v6_gst_candidates(
            pages
        )
    )


    selected = (
        _v6_select_gst_components(

            candidates,

            expected_tax,
        )
    )


    if not selected:

        return None


    selected_total = round(

        sum(

            float(
                item[
                    "amount"
                ]
            )

            for item
            in selected
        ),

        2,
    )


    if (
        abs(
            selected_total
            -
            expected_tax
        )
        >
        0.05
    ):

        return None


    return {

        "expected_tax":
            expected_tax,

        "selected_tax":
            selected_total,

        "components":
            selected,
    }


# ============================================================
# 9. FINANCIAL SEED STABILIZER
# ============================================================

_FINAL_OVERLAY_BASE = (
    _v6_apply_overlay
)


def _final_financial_overlay(
    input_path,
    base_result,
):

    seeded = copy.deepcopy(
        base_result
    )


    pages = (
        _v6_native_pages(
            input_path
        )
    )


    if pages:

        gl_base = (
            _final_gl_base_subtotal(
                pages
            )
        )


        words_total = (
            _final_amount_words_total(
                pages
            )
        )


        if (
            gl_base is not None

            and

            words_total is not None
        ):

            confirmation = (
                _final_confirm_financial_pair(

                    pages,

                    gl_base[
                        "amount"
                    ],

                    words_total[
                        "amount"
                    ],
                )
            )


            if confirmation is not None:

                subtotal = (
                    gl_base[
                        "amount"
                    ]
                )


                total = (
                    words_total[
                        "amount"
                    ]
                )


                tax = (
                    confirmation[
                        "selected_tax"
                    ]
                )


                _v6_set_field(

                    seeded,

                    "SUBTOTAL",

                    _v6_format_money(
                        subtotal
                    ),

                    "RULE_RECOVERED",

                    "GL_BASE_VALUE_FINAL",
                )


                _v6_set_field(

                    seeded,

                    "TOTAL_AMOUNT",

                    _v6_format_money(
                        total
                    ),

                    "RULE_RECOVERED",

                    "AMOUNT_IN_WORDS_TOTAL_FINAL",
                )


                _v6_set_field(

                    seeded,

                    "TAX",

                    _v6_format_money(
                        tax
                    ),

                    "RECONCILED",

                    "GST_ARITHMETIC_SEED_FINAL",
                )


    return (
        _FINAL_OVERLAY_BASE(

            input_path,

            seeded,
        )
    )


_v6_apply_overlay = (
    _final_financial_overlay
)


# ============================================================
# 10. V3 NEURAL PREVIEW
# ============================================================

def _final_neural_preview(
    input_path,
):

    input_path = Path(
        input_path
    )


    document_id = re.sub(

        r"[^A-Za-z0-9_.-]+",

        "_",

        input_path.stem,
    )


    debug_path = (

        Path(
            PROD_WORK_ROOT
        )

        /

        document_id

        /

        "processing_debug.json"
    )


    if not debug_path.exists():

        return {}


    try:

        with open(

            debug_path,

            "r",

            encoding="utf-8",

        ) as file:

            data = json.load(
                file
            )


        preview = data.get(
            "neural_preview",
            {}
        )


        return (
            preview

            if isinstance(
                preview,
                dict
            )

            else {}
        )


    except Exception:

        return {}


# ============================================================
# 11. DOCUMENT TEXT
# ============================================================

def _final_document_text(
    pages,
):

    lines = []


    for page in pages:

        for row in page.get(
            "rows",
            []
        ):

            text = str(

                row.get(
                    "text",
                    ""
                )

            ).strip()


            if text:

                lines.append(
                    text
                )


    return "\n".join(
        lines
    )


def _final_has_due_date_evidence(
    text,
):

    patterns = [

        r"\bdue\s*date\b",

        r"\bpayment\s+due\b",

        r"\bdue\s+on\b",

        r"\bpayable\s+by\b",

        r"\bdate\s+due\b",
    ]


    lower = str(
        text
    ).lower()


    return any(

        re.search(
            pattern,
            lower
        )

        for pattern
        in patterns
    )


def _final_has_payment_terms_evidence(
    text,
):

    patterns = [

        r"\bpayment\s*terms?\b",

        r"\bterms?\s+of\s+payment\b",

        r"\bcredit\s*terms?\b",

        r"\bpayment\s+condition\b",

        r"\bnet\s*\d{1,3}\b",
    ]


    lower = str(
        text
    ).lower()


    return any(

        re.search(
            pattern,
            lower
        )

        for pattern
        in patterns
    )


def _final_has_discount_evidence(
    text,
):

    patterns = [

        r"\bdiscount\b",

        r"\bdisc\.?\b",

        r"\brebate\b",
    ]


    lower = str(
        text
    ).lower()


    return any(

        re.search(
            pattern,
            lower
        )

        for pattern
        in patterns
    )


# ============================================================
# 12. OPTIONAL FIELD / SUMMARY OVERLAY
# ============================================================

_FINAL_OVERLAY_FINANCIAL = (
    _v6_apply_overlay
)


def _final_optional_overlay(
    input_path,
    base_result,
):

    result = (
        _FINAL_OVERLAY_FINANCIAL(

            input_path,

            base_result,
        )
    )


    result[
        "schema_version"
    ] = (
        "invoice_ai_v3_allrounder_final"
    )


    fields = result[
        "fields"
    ]


    pages = (
        _v6_native_pages(
            input_path
        )
    )


    document_text = (
        _final_document_text(
            pages
        )
    )


    neural_preview = (
        _final_neural_preview(
            input_path
        )
    )


    # --------------------------------------------------------
    # Due Date
    # --------------------------------------------------------

    if (
        not _final_has_due_date_evidence(
            document_text
        )

        and

        fields[
            "DUE_DATE"
        ].get(
            "source"
        )
        ==
        "NEURAL"
    ):

        _v6_set_field(

            result,

            "DUE_DATE",

            NOT_DETECTED,

            "NOT_PRESENT",

            "NO_DUE_DATE_EVIDENCE_FINAL",
        )


    # --------------------------------------------------------
    # V3 Payment Terms
    # --------------------------------------------------------

    payment_terms = (
        neural_preview.get(
            "PAYMENT_TERMS",
            NOT_DETECTED
        )
    )


    if (
        _final_has_payment_terms_evidence(
            document_text
        )

        and

        not _v6_missing(
            payment_terms
        )
    ):

        _v6_set_field(

            result,

            "PAYMENT_TERMS",

            payment_terms,

            "NEURAL",

            "NEURAL_V3_PAYMENT_TERMS",
        )


    elif _v6_missing(

        fields[
            "PAYMENT_TERMS"
        ][
            "value"
        ]
    ):

        _v6_set_field(

            result,

            "PAYMENT_TERMS",

            NOT_DETECTED,

            "NOT_PRESENT",

            "NO_PAYMENT_TERMS_EVIDENCE_FINAL",
        )


    # --------------------------------------------------------
    # Discount
    # --------------------------------------------------------

    if (
        not _final_has_discount_evidence(
            document_text
        )

        and

        fields[
            "DISCOUNT"
        ].get(
            "source"
        )
        ==
        "NEURAL"
    ):

        _v6_set_field(

            result,

            "DISCOUNT",

            NOT_DETECTED,

            "NOT_PRESENT",

            "NO_DISCOUNT_EVIDENCE_FINAL",
        )


    # --------------------------------------------------------
    # Clean stale not_present
    # --------------------------------------------------------

    validation = result.setdefault(
        "validation",
        {}
    )


    existing_not_present = set(

        validation.get(
            "not_present_fields",
            []
        )
    )


    not_present = {

        field

        for field
        in existing_not_present

        if (
            field
            in fields

            and

            _v6_missing(

                fields[
                    field
                ][
                    "value"
                ]
            )
        )
    }


    for field in [

        "DUE_DATE",

        "DISCOUNT",

        "PAYMENT_TERMS",

    ]:

        if _v6_missing(

            fields[
                field
            ][
                "value"
            ]
        ):

            not_present.add(
                field
            )


    validation[
        "not_present_fields"
    ] = sorted(
        not_present
    )


    return result


_v6_apply_overlay = (
    _final_optional_overlay
)


# ============================================================
# 13. ADDRESS BOUNDARY HELPERS
# ============================================================

def _final_clean_spaces(
    value,
):

    return re.sub(

        r"\s+",

        " ",

        str(
            value or ""
        ).strip(),
    )


def _final_address_norm(
    value,
):

    return re.sub(

        r"[^a-z0-9]+",

        "",

        str(
            value
        ).lower(),
    )


def _final_address_like(
    value,
):

    text = str(
        value or ""
    )


    if len(
        text
    ) < 15:

        return False


    lower = text.lower()


    has_number = any(

        character.isdigit()

        for character
        in text
    )


    markers = [

        "road",

        "street",

        "nagar",

        "floor",

        "palayam",

        "taluk",

        "district",

        "dist",

        "market",

        "village",

        "post",

        "plot",

        "sector",

        "industrial",

        "area",

        "pincode",
    ]


    marker_count = sum(

        1

        for marker
        in markers

        if re.search(

            rf"\b{re.escape(marker)}\b",

            lower,
        )
    )


    return (
        has_number

        or

        marker_count >= 2
    )


def _final_choose_native_address(
    neural,
    native,
):

    neural = (
        _final_clean_spaces(
            neural
        )
    )


    native = (
        _final_clean_spaces(
            native
        )
    )


    if not neural:

        return (
            native or None
        )


    if not native:

        return None


    if not _final_address_like(
        native
    ):

        return None


    neural_norm = (
        _final_address_norm(
            neural
        )
    )


    native_norm = (
        _final_address_norm(
            native
        )
    )


    if (
        not neural_norm

        or

        not native_norm
    ):

        return None


    similarity = SequenceMatcher(

        None,

        neural_norm,

        native_norm,

    ).ratio()


    containment = (

        native_norm
        in neural_norm

        or

        neural_norm
        in native_norm
    )


    size_ratio = (

        min(
            len(
                neural_norm
            ),
            len(
                native_norm
            ),
        )

        /

        max(
            len(
                neural_norm
            ),
            len(
                native_norm
            ),
        )
    )


    strong_match = (

        containment

        or

        (
            similarity >= 0.78

            and

            size_ratio >= 0.65
        )
    )


    return (
        native

        if strong_match

        else None
    )


# ============================================================
# 14. ADDRESS BOUNDARY + FINAL FIELD ACCOUNTING
# ============================================================

_FINAL_OVERLAY_OPTIONAL = (
    _v6_apply_overlay
)


def _final_address_and_accounting_overlay(
    input_path,
    base_result,
):

    result = (
        _FINAL_OVERLAY_OPTIONAL(

            input_path,

            base_result,
        )
    )


    fields = result[
        "fields"
    ]


    pages = (
        _v6_native_pages(
            input_path
        )
    )


    vendor = (

        fields
        .get(
            "VENDOR_NAME",
            {}
        )
        .get(
            "value"
        )
    )


    address_data = fields.get(
        "ADDRESS",
        {}
    )


    current_address = (
        address_data.get(
            "value"
        )
    )


    current_source = (
        address_data.get(
            "source",
            ""
        )
    )


    native_address = None


    if (
        pages

        and

        not _v6_missing(
            vendor
        )
    ):

        try:

            native_address = (
                _v6_vendor_address(

                    pages[
                        0
                    ],

                    vendor,
                )
            )


        except Exception:

            native_address = None


    if (
        current_source
        ==
        "NEURAL"

        and

        not _v6_missing(
            current_address
        )

        and

        native_address
    ):

        selected = (
            _final_choose_native_address(

                current_address,

                native_address,
            )
        )


        if (
            selected

            and

            selected
            !=
            current_address
        ):

            _v6_set_field(

                result,

                "ADDRESS",

                selected,

                "RULE_RECOVERED",

                "NATIVE_HEADER_ADDRESS_BOUNDARY_FINAL",
            )


    # --------------------------------------------------------
    # Expose V6 financial details at top level.
    # --------------------------------------------------------

    financial_details = (
        result.get(
            "financial_details",
            {}
        )
    )


    result[
        "adjustments"
    ] = financial_details.get(
        "adjustments",
        []
    )


    result[
        "round_off"
    ] = financial_details.get(
        "round_off"
    )


    # --------------------------------------------------------
    # Final field accounting.
    # --------------------------------------------------------

    validation = result.setdefault(
        "validation",
        {}
    )


    summary = result.setdefault(
        "extraction_summary",
        {}
    )


    fields_with_values = [

        field

        for field in TARGET_FIELDS

        if not _v6_missing(

            fields[
                field
            ].get(
                "value"
            )
        )
    ]


    confirmed_absent = [

        field

        for field
        in validation.get(
            "not_present_fields",
            []
        )

        if (
            field
            in TARGET_FIELDS

            and

            _v6_missing(

                fields[
                    field
                ].get(
                    "value"
                )
            )
        )
    ]


    unresolved = [

        field

        for field
        in TARGET_FIELDS

        if (
            field
            not in fields_with_values

            and

            field
            not in confirmed_absent
        )
    ]


    accounted = [

        field

        for field
        in TARGET_FIELDS

        if (
            field
            in fields_with_values

            or

            field
            in confirmed_absent
        )
    ]


    summary[
        "target_field_count"
    ] = 16


    summary[
        "fields_with_values_count"
    ] = len(
        fields_with_values
    )


    summary[
        "fields_with_values"
    ] = fields_with_values


    summary[
        "confirmed_absent_field_count"
    ] = len(
        confirmed_absent
    )


    summary[
        "confirmed_absent_fields"
    ] = confirmed_absent


    summary[
        "accounted_for_field_count"
    ] = len(
        accounted
    )


    summary[
        "accounted_for_fields"
    ] = accounted


    summary[
        "unresolved_field_count"
    ] = len(
        unresolved
    )


    summary[
        "unresolved_expected_fields"
    ] = unresolved


    # Compatibility with existing display.
    summary[
        "resolved_field_count"
    ] = len(
        accounted
    )


    summary[
        "resolved_fields"
    ] = accounted


    summary[
        "not_present_fields"
    ] = confirmed_absent


    validation[
        "field_accounting_pass"
    ] = (
        len(
            unresolved
        )
        ==
        0
    )


    return result


_v6_apply_overlay = (
    _final_address_and_accounting_overlay
)


# ============================================================
# 15. DANGLING ADDRESS SUFFIX CLEANER
# ============================================================

def _final_trim_address_suffix(
    value,
):

    if _v6_missing(
        value
    ):

        return value


    original = str(
        value
    ).strip()


    text = original


    pattern = re.compile(

        r"""
        (?:[,\s]+)?

        \b
        (?:
            dist
            |
            district
            |
            pin
            |
            pincode
            |
            state
            |
            taluk
            |
            taluka
            |
            tehsil
            |
            post
            |
            po
            |
            village
            |
            city
        )
        \b

        \s*
        [:\-–—]*
        \s*
        [,;]*

        $
        """,

        flags=(
            re.IGNORECASE
            |
            re.VERBOSE
        ),
    )


    text = pattern.sub(
        "",
        text,
    )


    text = re.sub(

        r"[\s,;:\-–—]+$",

        "",

        text,
    ).strip()


    if len(
        text
    ) < 10:

        return original


    return text


_FINAL_OVERLAY_ADDRESS = (
    _v6_apply_overlay
)


def _final_complete_overlay(
    input_path,
    base_result,
):

    result = (
        _FINAL_OVERLAY_ADDRESS(

            input_path,

            base_result,
        )
    )


    address_field = (

        result
        .get(
            "fields",
            {}
        )
        .get(
            "ADDRESS",
            {}
        )
    )


    current = (
        address_field.get(
            "value"
        )
    )


    if not _v6_missing(
        current
    ):

        cleaned = (
            _final_trim_address_suffix(
                current
            )
        )


        if cleaned != current:

            _v6_set_field(

                result,

                "ADDRESS",

                cleaned,

                "RULE_RECOVERED",

                "ADDRESS_BOUNDARY_CLEANUP_FINAL",
            )


    return result


_v6_apply_overlay = (
    _final_complete_overlay
)


# ============================================================
# 16. UNIT CHECKS
# ============================================================

assert (
    _final_trim_address_suffix(
        "ABC ROAD, CHENNAI, DIST-"
    )
    ==
    "ABC ROAD, CHENNAI"
)


assert (
    _final_trim_address_suffix(
        "ABC ROAD, DIST- DINDIGUL"
    )
    ==
    "ABC ROAD, DIST- DINDIGUL"
)


assert len(
    TARGET_FIELDS
) == 16


assert callable(
    process_invoice_final
)


assert callable(
    _v6_apply_overlay
)


_INVOICE_AI_V3_FINAL_PATCH_APPLIED = True


print("=" * 92)
print("🏆 FINAL V3 PRODUCTION INTEGRATION PATCH READY")
print("=" * 92)
print("✅ List-safe V3")
print("✅ Geometry cache")
print("✅ GST closeness protection")
print("✅ GL financial recovery")
print("✅ Split GL headers")
print("✅ Due-date evidence guard")
print("✅ V3 payment terms")
print("✅ Discount evidence guard")
print("✅ Address boundary recovery")
print("✅ Dangling address suffix cleanup")
print("✅ Final field accounting")
print("✅ No model reload")
print("✅ No processor reload")
print("=" * 92)
