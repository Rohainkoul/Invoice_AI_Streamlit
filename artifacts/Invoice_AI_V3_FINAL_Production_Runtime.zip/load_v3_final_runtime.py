
# ============================================================
# INVOICE AI V3 — FINAL PERMANENT RUNTIME LOADER
#
# REQUIREMENTS BEFORE RUNNING:
#
# MODEL
# PROCESSOR
# TARGET_FIELDS
# LABEL_LIST
# id2label
# label2id
#
# must already be loaded from:
#
# Invoice_AI_V3_AllRounder_FINAL.zip
#
# ============================================================

from pathlib import Path

import os
import shutil


print("=" * 92)
print("🔥 LOADING INVOICE AI V3 FINAL PRODUCTION RUNTIME")
print("=" * 92)


# ============================================================
# 1. VERIFY MODEL
# ============================================================

_required_model = [

    "MODEL",

    "PROCESSOR",

    "TARGET_FIELDS",

    "LABEL_LIST",

    "id2label",

    "label2id",
]


for _name in _required_model:

    if _name not in globals():

        raise RuntimeError(
            f"Missing {_name}. Load V3 model first."
        )


if (
    MODEL.__class__.__name__
    !=
    "LayoutLMv3ForTokenClassification"
):

    raise RuntimeError(
        "Wrong model architecture."
    )


if len(
    TARGET_FIELDS
) != 16:

    raise RuntimeError(
        "Expected 16 target fields."
    )


if len(
    LABEL_LIST
) != 33:

    raise RuntimeError(
        "Expected 33 BIO labels."
    )


# ============================================================
# 2. LOCATE BUNDLE DIRECTORY ROBUSTLY
# ============================================================

def _locate_final_bundle():

    candidates = []


    # __file__ when loader is run normally.
    _file = globals().get(
        "__file__"
    )


    if _file:

        _path = Path(
            _file
        )


        if (
            _path.name
            ==
            "load_v3_final_runtime.py"

            and

            _path.exists()
        ):

            candidates.append(
                _path.parent
            )


    # Current working directory.
    _cwd_candidate = (

        Path.cwd()

        /

        "load_v3_final_runtime.py"
    )


    if _cwd_candidate.exists():

        candidates.append(
            _cwd_candidate.parent
        )


    # Colab extraction fallback.
    for _path in Path(
        "/content"
    ).rglob(
        "load_v3_final_runtime.py"
    ):

        candidates.append(
            _path.parent
        )


    unique = []


    for _candidate in candidates:

        try:

            _candidate = (
                _candidate.resolve()
            )

        except Exception:

            pass


        if _candidate not in unique:

            unique.append(
                _candidate
            )


    valid = [

        _candidate

        for _candidate
        in unique

        if (

            _candidate
            /
            "load_v3_v6_1_runtime.py"
        ).exists()

        and

        (

            _candidate
            /
            "Invoice_AI_V3_Final_Integration_Patch.py"
        ).exists()
    ]


    if len(
        valid
    ) == 0:

        raise FileNotFoundError(
            "Could not locate final V3 runtime bundle."
        )


    return valid[
        0
    ]


FINAL_BUNDLE_DIR = (
    _locate_final_bundle()
)


print(
    "✅ Final bundle:",
    FINAL_BUNDLE_DIR
)


# ============================================================
# 3. LOAD VERIFIED ORIGINAL V6.1 STACK
# ============================================================

OLD_LOADER = (

    FINAL_BUNDLE_DIR

    /

    "load_v3_v6_1_runtime.py"
)


SOURCE_NOTEBOOK = (

    FINAL_BUNDLE_DIR

    /

    "V6_1_VERIFIED_PRODUCTION_SOURCE.ipynb"
)


if not SOURCE_NOTEBOOK.exists():

    raise FileNotFoundError(
        SOURCE_NOTEBOOK
    )


# Old loader compatibility fallback.
_CONTENT_SOURCE = Path(
    "/content/V6_1_VERIFIED_PRODUCTION_SOURCE.ipynb"
)


if not _CONTENT_SOURCE.exists():

    shutil.copy2(

        SOURCE_NOTEBOOK,

        _CONTENT_SOURCE,
    )


_old_source = OLD_LOADER.read_text(
    encoding="utf-8"
)


_previous_cwd = os.getcwd()


_sentinel = object()


_previous_file = globals().get(
    "__file__",
    _sentinel,
)


try:

    globals()[
        "__file__"
    ] = str(
        OLD_LOADER
    )


    os.chdir(
        str(
            FINAL_BUNDLE_DIR
        )
    )


    exec(

        compile(

            _old_source,

            str(
                OLD_LOADER
            ),

            "exec",
        ),

        globals(),
    )


finally:

    os.chdir(
        _previous_cwd
    )


    if _previous_file is _sentinel:

        globals().pop(
            "__file__",
            None,
        )

    else:

        globals()[
            "__file__"
        ] = _previous_file


# ============================================================
# 4. APPLY FINAL V3 INTEGRATION
# ============================================================

globals().pop(
    "_INVOICE_AI_V3_FINAL_PATCH_APPLIED",
    None,
)


PATCH_FILE = (

    FINAL_BUNDLE_DIR

    /

    "Invoice_AI_V3_Final_Integration_Patch.py"
)


_patch_source = PATCH_FILE.read_text(
    encoding="utf-8"
)


exec(

    compile(

        _patch_source,

        str(
            PATCH_FILE
        ),

        "exec",
    ),

    globals(),
)


# ============================================================
# 5. FINAL VERIFICATION
# ============================================================

if not globals().get(
    "_INVOICE_AI_V3_FINAL_PATCH_APPLIED"
):

    raise RuntimeError(
        "Final V3 integration patch did not load."
    )


if not callable(
    process_invoice_final
):

    raise RuntimeError(
        "process_invoice_final unavailable."
    )


print()
print("=" * 92)
print("🏆 INVOICE AI V3 FINAL PRODUCTION ENGINE READY")
print("=" * 92)

print(
    "Architecture :",
    MODEL.__class__.__name__
)

print(
    "Device       :",
    next(
        MODEL.parameters()
    ).device
)

print(
    "Fields       :",
    len(
        TARGET_FIELDS
    )
)

print(
    "BIO labels   :",
    len(
        LABEL_LIST
    )
)

print()
print("✅ V6.1 verified engine")
print("✅ Final V3 integration")
print("✅ List safety")
print("✅ GST / financial protection")
print("✅ Optional-field evidence guards")
print("✅ Address boundary cleanup")
print("✅ Final field accounting")
print("✅ MODEL not reloaded")
print("✅ PROCESSOR not reloaded")
print("✅ NO training")

print()
print(
    "🔥 ENTRY POINT:"
)

print(
    "process_invoice_final('/content/invoice.pdf')"
)

print("=" * 92)
