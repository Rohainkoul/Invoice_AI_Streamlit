Invoice AI V3 + V6.1 Runtime Bundle

Use after Colab Cell 2 has loaded:
- MODEL
- PROCESSOR
- TARGET_FIELDS
- LABEL_LIST
- id2label
- label2id

This bundle contains the verified prior inference stack only.
It does not contain model weights or training data.

Colab usage:
1. Upload Invoice_AI_V3_V6_1_Runtime_Bundle.zip
2. Extract it
3. exec(open('load_v3_v6_1_runtime.py').read(), globals())
4. Call process_invoice_final('/content/invoice.pdf')
