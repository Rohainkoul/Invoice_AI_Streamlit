# ============================================================
# Invoice AI V3 All-Rounder — VERIFIED V6.1 RUNTIME LOADER
# ============================================================
# REQUIREMENTS:
#   MODEL, PROCESSOR, TARGET_FIELDS, LABEL_LIST, id2label,
#   label2id must already be loaded by the V3 model cell.
#
# This loader reuses the verified production inference stack:
#   base processor -> quality patch -> V3 hotfix -> V4 -> V5
#   -> V6 -> V6.1
#
# NO TRAINING.
# NO MODEL RELOAD.
# NO PROCESSOR RELOAD.
# ============================================================

from pathlib import Path
import json

BUNDLE_DIR = Path(globals().get("_V3_V61_BUNDLE_DIR", Path.cwd())).resolve()

_REQUIRED_GLOBALS = [
    "MODEL",
    "PROCESSOR",
    "TARGET_FIELDS",
    "LABEL_LIST",
    "id2label",
    "label2id",
]

for _name in _REQUIRED_GLOBALS:
    if _name not in globals():
        raise RuntimeError(
            f"Missing {_name}. Run the V3 production model loader first."
        )

if len(TARGET_FIELDS) != 16:
    raise RuntimeError(f"Expected 16 target fields, found {len(TARGET_FIELDS)}.")

if len(LABEL_LIST) != 33:
    raise RuntimeError(f"Expected 33 BIO labels, found {len(LABEL_LIST)}.")

print("=" * 92)
print("🔥 LOADING VERIFIED V6.1 INFERENCE STACK ON TOP OF V3 🔥")
print("=" * 92)
print("Model:", MODEL.__class__.__name__)
print("Device:", next(MODEL.parameters()).device)
print("Fields:", len(TARGET_FIELDS))
print("BIO labels:", len(LABEL_LIST))


def _exec_source(source, pseudo_name):
    code = compile(source, pseudo_name, "exec")
    exec(code, globals(), globals())


def _exec_notebook_cell(marker):
    notebook_path = BUNDLE_DIR / "V6_1_VERIFIED_PRODUCTION_SOURCE.ipynb"

    with open(notebook_path, "r", encoding="utf-8") as f:
        notebook = json.load(f)

    matches = []

    for index, cell in enumerate(notebook.get("cells", [])):
        if cell.get("cell_type") != "code":
            continue

        source = "".join(cell.get("source", []))

        if marker in source:
            matches.append((index, source))

    if len(matches) != 1:
        raise RuntimeError(
            f"Expected exactly one notebook code cell containing {marker!r}; "
            f"found {len(matches)}."
        )

    index, source = matches[0]

    # Rename only the runtime output folder. Logic remains unchanged.
    source = source.replace(
        '"/content/Invoice_AI_V2"',
        '"/content/Invoice_AI_V3_Production"',
    )

    print(f"\n▶ Loading notebook runtime cell {index}: {marker}")
    _exec_source(
        source,
        f"<V6.1 source notebook cell {index}>",
    )
    print("✅ Loaded")


def _exec_py(filename):
    path = BUNDLE_DIR / filename

    if not path.exists():
        raise FileNotFoundError(path)

    print(f"\n▶ Loading {filename}")

    source = path.read_text(encoding="utf-8")

    source = source.replace(
        '"/content/Invoice_AI_V2"',
        '"/content/Invoice_AI_V3_Production"',
    )

    _exec_source(source, str(path))
    print("✅ Loaded")


# 1) Base reusable inference + ingestion/OCR pipeline
_exec_notebook_cell(
    "CELL 9 — REUSABLE END-TO-END INVOICE PROCESSOR"
)

# 2) Generic production quality layer
_exec_notebook_cell(
    "CELL 10B — GENERIC PRODUCTION QUALITY PATCH"
)

# 3) Verified robustness patches in their original order
_exec_py("Invoice_AI_V2_Runtime_Hotfix_v3.py")
_exec_py("Invoice_AI_V2_Runtime_Hotfix_v4.py")
_exec_py("Invoice_AI_V2_Runtime_Hotfix_v5.py")
_exec_py("Invoice_AI_V2_ULTIMATE_Runtime_Fix_V6.py")
_exec_py("Invoice_AI_V2_Runtime_Hotfix_V6_1_BlindBatch.py")

# 4) Preserve the verified V6.1 callable, then add V3 metadata.
_PROCESS_INVOICE_V61 = process_invoice_final


def process_invoice_v3_allrounder(input_path, verbose=True):
    """V3 LayoutLMv3 weights + verified V6.1 inference/rule engine."""

    result = _PROCESS_INVOICE_V61(
        input_path,
        verbose=verbose,
    )

    result["schema_version"] = "invoice_ai_v3_allrounder_v6_1"

    result["runtime"] = {
        "model": "Invoice_AI_V3_AllRounder",
        "model_architecture": "LayoutLMv3ForTokenClassification",
        "target_fields": 16,
        "bio_labels": 33,
        "inference_engine": "V6.1",
        "training": False,
    }

    # Original V6 writes JSON before this wrapper adds V3 metadata,
    # so overwrite the same canonical file once more.
    document_id = result.get("document", {}).get("document_id")

    if document_id:
        output_path = (
            Path(PROD_OUTPUT_ROOT)
            / f"{document_id}_invoice_extraction.json"
        )

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(
                result,
                f,
                indent=2,
                ensure_ascii=False,
            )

        result["final_json_path"] = str(output_path)

    return result


# Canonical public entry point.
process_invoice_final = process_invoice_v3_allrounder


# 5) Hard self-check
if "_v6_apply_overlay" not in globals():
    raise RuntimeError("V6 overlay missing.")

if "_V61_NATIVE_READER_ORIGINAL" not in globals():
    raise RuntimeError("V6.1 patch missing.")

if "quality_records_v2" not in globals():
    raise RuntimeError("Quality record loader missing.")

if not callable(process_invoice_final):
    raise RuntimeError("Final processor is not callable.")

print()
print("=" * 92)
print("🏆 V3 + V6.1 PRODUCTION INFERENCE ENGINE READY")
print("=" * 92)
print("✅ V3 MODEL remains loaded — no reload")
print("✅ Base native PDF processor loaded")
print("✅ OCR fallback loaded")
print("✅ BIO extraction loaded")
print("✅ Anchor / regex recovery loaded")
print("✅ GST + financial reconciliation loaded")
print("✅ Material / line-table reconstruction loaded")
print("✅ V3/V4/V5 robustness patches loaded")
print("✅ V6 production overlay loaded")
print("✅ V6.1 generalization patch loaded")
print("✅ Final entry point: process_invoice_final(path)")
print("✅ NO TRAINING performed")
print("=" * 92)
