# ============================================================
# Invoice AI V2 — Runtime Hotfix V4
# Apply AFTER V3 is already loaded. No model reload/retraining.
#
# Fixes observed in 8176012501:
# 1) Rejects TAX when it is actually the sum of line-item quantities.
# 2) Allows small subtotal→final-total round-off when no valid tax exists.
# 3) Rejects obvious customer false positives like "TIN & CST Number must".
# 4) Removes stray currency prefix (e.g. "INR ") from line descriptions.
# ============================================================

import re

assert "_refresh_v3" in globals(), "Run V3 hotfix first."
assert "process_invoice_v3" in globals(), "Run V3 hotfix first."
assert "quality_records_v2" in globals(), "Run production V2/V3 cells first."

# Keep the original V3 refresher only once, so rerunning V4 is safe.
if "_refresh_v3_before_v4" not in globals():
    _refresh_v3_before_v4 = _refresh_v3


def _customer_is_bad_v4(value):
    if value is None:
        return True

    text = str(value).strip()

    if not text or text == NOT_DETECTED:
        return True

    if text.count("(") != text.count(")"):
        return True

    tokens = {
        re.sub(r"[^a-z0-9]+", "", token.lower())
        for token in text.split()
    }
    tokens.discard("")

    suspicious = {
        "tin", "cst", "gst", "gstin",
        "number", "must", "mention",
        "invoice", "date", "tax",
        "address", "pan", "cin",
    }

    # A party name should not mostly look like a compliance/instruction phrase.
    suspicious_count = sum(token in suspicious for token in tokens)

    if suspicious_count >= 2:
        return True

    if not any(any(ch.isalpha() for ch in token) for token in tokens):
        return True

    return False


def _recover_customer_v4(records):
    # Deliberately use strong party anchors only.
    anchor_phrases = [
        ("bill", "to"),
        ("billed", "to"),
        ("buyer", "name"),
        ("buyer",),
        ("consignee", "name"),
        ("consignee",),
        ("sold", "to"),
        ("customer", "name"),
    ]

    hard_stop = {
        "gst", "gstin", "tin", "cst", "pan", "cin",
        "address", "state", "pincode", "pin",
        "phone", "mobile", "email",
        "invoice", "date", "tax",
        "material", "description", "qty", "quantity",
        "rate", "amount", "hsn", "sac",
    }

    for phrase in anchor_phrases:
        hits = phrase_hits_v2(records, phrase)

        for hit in hits:
            following = records[
                hit["list_end"] + 1:
                min(len(records), hit["list_end"] + 14)
            ]

            collected = []

            for rec in following:
                raw = str(rec["word"]).strip()
                norm = rec["norm"]

                if not raw:
                    continue

                if norm in hard_stop:
                    if collected:
                        break
                    continue

                # Skip obvious IDs/codes before the party name.
                compact = re.sub(r"[^A-Za-z0-9]", "", raw)
                if (
                    not collected
                    and any(ch.isdigit() for ch in compact)
                    and len(compact) >= 8
                ):
                    continue

                # Once a name starts, digits usually signal address/GST/phone.
                if collected and any(ch.isdigit() for ch in raw):
                    break

                collected.append(raw.strip(" :;,|"))

                if len(collected) >= 7:
                    break

            # Try longest-to-shortest candidate.
            for end in range(len(collected), 0, -1):
                candidate = " ".join(collected[:end]).strip()

                if not _customer_is_bad_v4(candidate):
                    return candidate

    return None


def _clean_description_v4(value):
    text = str(value).strip()

    # Remove accidental standalone currency token at description start.
    text = re.sub(
        r"^(?:INR|USD|EUR|GBP|AED|JPY|RS\.?)\s+",
        "",
        text,
        flags=re.I,
    )

    return text.strip()


def _refresh_v3(input_path, result):
    # First run all existing V3 logic.
    out = _refresh_v3_before_v4(input_path, result)

    fields = out["fields"]
    validation = out["validation"]

    records = quality_records_v2(input_path)

    # --------------------------------------------------------
    # 1. Customer-name false-positive protection
    # --------------------------------------------------------
    current_customer = fields["CUSTOMER_NAME"]["value"]

    if _customer_is_bad_v4(current_customer):
        recovered_customer = _recover_customer_v4(records)

        if recovered_customer:
            fields["CUSTOMER_NAME"] = {
                "value": recovered_customer,
                "status": "RULE_RECOVERED",
                "source": "STRICT_PARTY_ANCHOR_V4",
            }
        else:
            fields["CUSTOMER_NAME"] = {
                "value": NOT_DETECTED,
                "status": "NOT_DETECTED",
                "source": "REJECTED_FALSE_POSITIVE_V4",
            }

    # --------------------------------------------------------
    # 2. Clean line descriptions
    # --------------------------------------------------------
    desc_field = fields.get("LINE_ITEM_DESC", {})
    desc_values = desc_field.get("value")

    if isinstance(desc_values, list):
        desc_field["value"] = [
            _clean_description_v4(v)
            for v in desc_values
        ]

    for item in out.get("line_items", []):
        if item.get("description") not in {None, NOT_DETECTED}:
            item["description"] = _clean_description_v4(
                item["description"]
            )

    # --------------------------------------------------------
    # 3. Reject TAX if it is actually TOTAL QUANTITY
    # --------------------------------------------------------
    line_items = out.get("line_items", [])

    qty_values = [
        item.get("quantity_numeric")
        for item in line_items
        if item.get("quantity_numeric") is not None
    ]

    qty_sum = (
        round(sum(float(v) for v in qty_values), 2)
        if qty_values and len(qty_values) == len(line_items)
        else None
    )

    tax_value = money_v2(fields["TAX"]["value"])

    gst_components = (
        out.get("tax_details", {})
        .get("gst_components", [])
        or []
    )

    tax_rejected_as_quantity = False

    if (
        tax_value is not None
        and qty_sum is not None
        and not gst_components
        and abs(tax_value - qty_sum) <= 0.05
    ):
        tax_rejected_as_quantity = True

        fields["TAX"] = {
            "value": NOT_DETECTED,
            "status": "NOT_DETECTED",
            "source": "REJECTED_QUANTITY_FALSE_POSITIVE_V4",
        }

        out.setdefault("normalized", {})["tax"] = None
        out.setdefault("tax_details", {})["total_tax"] = None

        tax_value = None

    # --------------------------------------------------------
    # 4. Financial reconciliation with small round-off
    # --------------------------------------------------------
    subtotal = money_v2(fields["SUBTOTAL"]["value"])
    discount = money_v2(fields["DISCOUNT"]["value"])
    total = money_v2(fields["TOTAL_AMOUNT"]["value"])

    calculated = None
    difference = None
    passed = None
    round_off = None

    if subtotal is not None and total is not None:
        calculated = subtotal

        if tax_value is not None:
            calculated += tax_value

        if discount is not None:
            calculated -= discount

        calculated = round(calculated, 2)
        difference = round(abs(calculated - total), 2)

        # When there is no valid tax component, Indian invoices often
        # round the final payable value by a few paise.
        tolerance = 1.00 if tax_value is None else 0.05
        passed = difference <= tolerance

        if passed and tax_value is None:
            round_off = round(total - calculated, 2)

    validation["financial_reconciliation"] = {
        "subtotal": subtotal,
        "tax": tax_value,
        "discount": discount,
        "total_amount": total,
        "calculated_total": calculated,
        "round_off": round_off,
        "difference": difference,
        "passed": passed,
    }

    # --------------------------------------------------------
    # 5. Refresh core checks / warnings / flags / summary
    # --------------------------------------------------------
    core_fields = [
        "VENDOR_NAME",
        "INVOICE_NUMBER",
        "INVOICE_DATE",
        "CUSTOMER_NAME",
        "CURRENCY",
        "TOTAL_AMOUNT",
    ]

    def missing(v):
        if v is None:
            return True
        if isinstance(v, str):
            return v.strip() in {"", NOT_DETECTED}
        if isinstance(v, (list, tuple)):
            return len(v) == 0
        return False

    missing_core = [
        f for f in core_fields
        if missing(fields[f]["value"])
    ]

    validation["missing_core_fields"] = missing_core
    validation["core_fields_pass"] = not missing_core

    missing_all = [
        f for f in TARGET_FIELDS
        if missing(fields[f]["value"])
    ]

    warnings = [
        f"{f} was not detected."
        for f in missing_all
    ]

    if tax_rejected_as_quantity:
        warnings.append(
            "TAX prediction matched the total line-item quantity and "
            "was rejected as a likely false positive."
        )

    validation["warnings"] = warnings

    line_pass = (
        validation
        .get("line_item_reconciliation", {})
        .get("matches_subtotal")
    )

    gst_pass = (
        validation
        .get("gst_reconciliation", {})
        .get("matches_tax_total")
    )

    flags = []

    if passed is False:
        flags.append("FINANCIAL_RECONCILIATION_FAILED")

    if line_pass is False:
        flags.append("LINE_ITEM_RECONCILIATION_FAILED")

    if gst_components and gst_pass is False:
        flags.append("GST_RECONCILIATION_FAILED")

    if missing_core:
        flags.append("CORE_FIELDS_MISSING")

    if tax_rejected_as_quantity:
        flags.append("TAX_FALSE_POSITIVE_REJECTED")

    validation["quality_flags"] = flags

    # Tax being absent is not automatically fatal if financials reconcile
    # without it. A missing core field still requires review.
    review_required = (
        bool(missing_core)
        or passed is False
        or line_pass is False
        or (bool(gst_components) and gst_pass is False)
    )

    overall = (
        "REVIEW_REQUIRED"
        if review_required
        else "PASS"
    )

    validation["overall_status"] = overall
    out["document"]["status"] = overall

    resolved = [
        f for f in TARGET_FIELDS
        if not missing(fields[f]["value"])
    ]

    undetected = [
        f for f in TARGET_FIELDS
        if f not in resolved
    ]

    neural_fields = [
        f for f in resolved
        if fields[f].get("source") == "NEURAL"
    ]

    recovered = [
        f for f in resolved
        if f not in neural_fields
    ]

    out["extraction_summary"] = {
        "target_field_count": len(TARGET_FIELDS),
        "resolved_field_count": len(resolved),
        "undetected_field_count": len(undetected),
        "resolved_fields": resolved,
        "undetected_fields": undetected,
        "neural_fields": neural_fields,
        "recovered_or_reconciled_fields": recovered,
    }

    return out


# process_invoice_v3 resolves _refresh_v3 dynamically, so no model reload
# and no need to redefine the whole processor.
process_invoice_final = process_invoice_v3

print("=" * 88)
print("🔥 RUNTIME HOTFIX V4 READY 🔥")
print("✅ TAX-vs-quantity false-positive protection")
print("✅ Small round-off reconciliation")
print("✅ Strict customer-name validation")
print("✅ Line-description cleanup")
print("No retraining. No model reload.")
print("Rerun only the invoice-upload cell.")
print("=" * 88)
