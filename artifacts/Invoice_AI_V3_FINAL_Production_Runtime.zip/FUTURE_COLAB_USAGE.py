# AFTER CELL 2 LOADS THE FINAL V3 MODEL:

from google.colab import files
from pathlib import Path

import os
import shutil
import zipfile


uploaded = files.upload()

runtime_zip = next(
    Path("/content") / name
    for name in uploaded
    if name.lower().endswith(".zip")
)


runtime_dir = Path(
    "/content/Invoice_AI_V3_FINAL_Runtime"
)


if runtime_dir.exists():

    shutil.rmtree(
        runtime_dir
    )


runtime_dir.mkdir(
    parents=True,
    exist_ok=True
)


with zipfile.ZipFile(
    runtime_zip,
    "r",
) as archive:

    archive.extractall(
        runtime_dir
    )


loader = next(
    runtime_dir.rglob(
        "load_v3_final_runtime.py"
    )
)


source = loader.read_text(
    encoding="utf-8"
)


old_file = globals().get(
    "__file__"
)


globals()[
    "__file__"
] = str(
    loader
)


exec(
    compile(
        source,
        str(loader),
        "exec",
    ),
    globals(),
)


if old_file is None:

    globals().pop(
        "__file__",
        None,
    )

else:

    globals()[
        "__file__"
    ] = old_file


# READY:
# process_invoice_final("/content/invoice.pdf")
