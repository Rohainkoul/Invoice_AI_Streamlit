INVOICE AI V3 ALLROUNDER — FINAL PRODUCTION RUNTIME
===================================================

KEEP THESE TWO FILES:

1. Invoice_AI_V3_AllRounder_FINAL.zip
   Final trained LayoutLMv3 model.

2. Invoice_AI_V3_FINAL_Production_Runtime.zip
   Final production inference/runtime engine.


FINAL MODEL
-----------

Architecture:
LayoutLMv3ForTokenClassification

Parameters:
125,942,945

Target fields:
16

BIO labels:
33


TRAINING SETTINGS
-----------------

Epochs:
3

Batch size:
2

Gradient accumulation:
4

Effective batch:
8

Learning rate:
1e-5

Final training examples:
1920

India replay:
960

Global replay:
960

Source balance:
50 / 50


HELD-OUT TEST METRICS
---------------------

Indian synthetic test:
BIO token F1 = 100.00%
Entity-span F1 = 100.00%

Global Katanaml test:
BIO token F1 = 99.24%
Entity-span precision = 98.71%
Entity-span recall = 99.35%
Entity-span F1 = 99.03%

Equal-source composite:
BIO token F1 = 99.62%
Entity-span F1 = 99.51%


IMPORTANT
---------

99.51% is held-out entity-span F1.
It must NOT be described as 99.51% real-world invoice accuracy.

The 9/9 known reference regression result is also NOT blind accuracy.


PRODUCTION PIPELINE
-------------------

Invoice
-> native PDF extraction
-> OCR fallback when required
-> LayoutLMv3 V3
-> BIO extraction
-> anchors / regex
-> V3/V4/V5 robustness
-> V6 layout / GST / financial logic
-> V6.1 generalization
-> final V3 integration
-> final JSON


FINAL ENTRY POINT
-----------------

process_invoice_final('/content/invoice.pdf')


NO TRAINING IS PERFORMED BY THIS RUNTIME PACKAGE.
